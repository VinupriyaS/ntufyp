// Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#292b2c';

// Area Chart Example
//var ctx = d3.select("#myAreaChart").append("svg").attr("width", 30).attr("height", 30).append("circle").attr("cx", 25).attr("cy", 25).attr("r", 25).style("fill", "black");
/*var myLineChart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: ["Mar 1", "Mar 2", "Mar 3", "Mar 4", "Mar 5", "Mar 6"],
    datasets: [{
      label: "Sessions",
      lineTension: 0.3,
      backgroundColor: "rgba(2,117,216,0.2)",
      borderColor: "rgba(2,117,216,1)",
      pointRadius: 5,
      pointBackgroundColor: "rgba(2,117,216,1)",
      pointBorderColor: "rgba(255,255,255,0.8)",
      pointHoverRadius: 5,
      pointHoverBackgroundColor: "rgba(2,117,216,1)",
      pointHitRadius: 50,
      pointBorderWidth: 2,
      data: [10000, 30162, 26263, 18394, 18287, 28682],
    }],
  },
  options: {
    scales: {
      xAxes: [{
        time: {
          unit: 'date'
        },
        gridLines: {
          display: false
        },
        ticks: {
          maxTicksLimit: 7
        }
      }],
      yAxes: [{
        ticks: {
          min: 0,
          max: 40000,
          maxTicksLimit: 5
        },
        gridLines: {
          color: "rgba(0, 0, 0, .125)",
        }
      }],
    },
    legend: {
      display: false
    }
  }
});*/


//commented build_checklist to check other features
window.onclick = hideContextMenu;
      window.onkeydown = listenKeys;
      var contextMenu = document.getElementById('contextMenu');

      function showContextMenu (event) {
        contextMenu.style.display = 'block';
        contextMenu.style.left = event.clientX + 'px';
        contextMenu.style.top = event.clientY + 'px';
        return false;
      }

      function hideContextMenu () {
        contextMenu.style.display = 'none';
      }

      function listenKeys (event) {
        var keyCode = event.which || event.keyCode;
        if(keyCode == 27){
          hideContextMenu();
        }
      }
 var width = 900,
        height = 600;
var border=1;
var bordercolor='black';
var coll = document.getElementsByClassName("collapsible");
var palette=["#847b00",
"#014bcc",
"#e6c106",
"#b36df8",
"#009130",
"#ff76e0",
"#839d00",
"#008bf0",
"#fcba50",
"#404d98",
"#ffad7d",
"#6cb1ff",
"#cb0068",
"#00835b",
"#951b78",
"#91a7dd",
"#ff778c",
"#ba9bff",
"#ff91c5",
"#f2b1f1"];



var i;
window.addEventListener("DOMContentLoaded", function(event) {
   // document.getElementById('Export').addEventListener("click", openFile(event));
   // document.getElementById('linktype').onchange=link_type();

     $('#mySelect').multiselect({
  
    enableCollapsibleOptGroups: true,
       buttonContainer: '<div id="mySelect" />'
  
  });
          $('#mySelect .caret-container').click();


          var words = ['boat', 'bear', 'dog', 'drink', 'elephant', 'fruit'];

  $('#search').autocomplete({
    hints: words
  });

    $('ul.tabs li').click(function(){
    var tab_id = $(this).attr('data-tab');

    $('ul.tabs li').removeClass('current');
    $('.tab-content').removeClass('current');

    $(this).addClass('current');
    $("#"+tab_id).addClass('current');
  })

  
});

$(document).ready(function()
{


    $('.btn-open-popover').popover();
    
    // //popover option
    $("#bfs-popover").popover({
        title: 'Enter Start Node',
        content: $('#divContentHTML-bfs').html(),
        placement: 'right',
        html: true
    });
     $("#dfs-link").popover({
        title: 'Enter Start Node',
        content: $('#divContentHTML-dfs').html(),
        placement: 'right',
        html: true
    });
     $("#prims-link").popover({
        title: 'Enter Start Node',
        content: $('#divContentHTML-prims').html(),
        placement: 'right',
        html: true
    });
        $("#maxflow-link").popover({
        title: 'Enter Start Node',
        content: $('#divContentHTML-maxflow').html(),
        placement: 'right',
        html: true
    });
   $(document).on('click', '#start-dfs', function()
    {
      console.log()
      startnode=$('.popover-body').find('#startnode').val();
      var startid;
      graphData.nodes.filter(function(d){
        console.log("hee")
        if (d.name==startnode)
          startid=d.id
      })
      console.log(startid)
      if (startid) 
      {
         if(document.getElementById("linktype").value=="undirected")
            dfs_undirected(startid)
          else
            dfs(startid)
      }
      else
        alert("Start node does not exist. Please try again!")
     
     
    });

    $(document).on('click', '#start-bfs', function()
    {
      console.log()
      startnode=$('.popover-body').find('#startnode').val();
      var startid;
      graphData.nodes.filter(function(d){
        console.log("hee")
        if (d.name==startnode)
          startid=d.id
      })
      console.log(startid)
      if (startid) 
        {
          console.log(document.getElementById("linktype").value=="undirected")
          if(document.getElementById("linktype").value=="undirected")
            bfs_undirected(startid)
          else
            bfs(startid)


        }
      else
        alert("Start node does not exist. Please try again!")
     
     
    });
  $(document).on('click', '#start-prims', function()
    {
      console.log()
      startnode=$('.popover-body').find('#startnode').val();
      var startid;
      graphData.nodes.filter(function(d){
        console.log("hee")
        if (d.name==startnode)
          startid=d.id
      })
      console.log(startid)
      if (startid) 
        primsMST(startid)
      else
        alert("Start node does not exist. Please try again!")
     
     
    });
  $(document).on('click', '#start-maxflow', function()
    {
      console.log("hel")
      startnode=$('.popover-body').find('#sourcenode').val();
      targetnode=$('.popover-body').find("#sinknode").val()
      var source,sink;
      graphData.nodes.filter(function(d){
        console.log("hee")
        if (d.name==startnode)
          source=d.index
      })
      //console.log(startid)
      graphData.nodes.filter(function(d){
        console.log("hee")
        if (d.name==targetnode)
          sink=d.index
      })
      console.log(source)
      console.log(sink)
      //if (source && sink ) 
        solveFlow(source,sink)
      //else
        //alert("Start node does not exist. Please try again!")
     
     
    });

     var checkbox = document.getElementById('myonoffswitch');
  checkbox.addEventListener('change', function () {
    if (checkbox.checked) {
      // do this
   // area where the lasso can be started
      //lasso.on("start",lasso_start) // lasso start function
      //.on("draw",lasso_draw) // lasso draw function
      //.on("end",lasso_end); // lasso end function
     //svg.call(lasso)
     //alert('Checked');
    } else {
      // do that
                 svg.selectAll(".lasso").remove();
                 lasso.on("start",null) // lasso start function
      .on("draw",null) // lasso draw function
      .on("end",null)
    
// lasso end function
      //alert('Not checked');
    }
  });
});

function startnode(){
  console.log($("#startnode").val())
}
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("trigger");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal 
 function modal_Open(node) {
  //alert("he")
  //alert(node.name)
  //document.getElementById("myModal").innerHTML = "<p>some text</p>";
    /*var mymodal = $('#myModal');
    mymodal.find('.modal-content').text('hello');
    mymodal.find('.modal-content').text('world');
    mymodal.modal('show');*/
    console.log(node)
    console.log(d3.keys(node))
   var prop=new Set(["index","weight","x","y","px","py","selected","possible","fixed"]);
    var validList = d3.keys(node).filter((item) => {
  return !prop.has(item);
})

  
    console.log(validList)

  var table= d3.select("#modal_table")
     var th= table.select('#tablecols').selectAll("th").data(validList)
     th.enter().append('th')


       th.text(function (column) { return column; });

       th.exit().remove()

    var tr=table.select("#tablebody")
    tr.data(node)
    
    //tr.exit().remove()

    var cells = tr.selectAll('td').data(function (row) {
        console.log("HE")
        return validList.map(function (column) {
          console.log(column)
          console.log(node[column])
          return {column: column, value: node[column]};
        });
      })
      cells.enter()
      .append('td')
      .on("input",function(d){
        //alert(node.id)
        //alert(d.value)
       //console.log(d)
        //console.log(document.getElementById(d.column).innerHTML)
        console.log(document.getElementById("id").innerHTML)
        id=document.getElementById("id").innerHTML
        for (element in document.getElementById("tablebody"))
          if (element.id=="id")
            id=element.value
        console.log(id)
         var rows=document.getElementsByClassName("td_edit")

        //JEHHH
        //document.getElementById("saveAttr").addEventListener("click",updatenodeattr(d.id,d.column))
        graphData.nodes.filter(function(k){
     
          if (k.id==id)
           { 
            console.log(k.id)
           //console.log(node.id)
           console.log(id)
            k[d.column]=document.getElementById(d.column).innerHTML
            update()
            return
           }
           /*if (k.id==node.id)
            alert("Hbehn")*/

        })
      })
      console.log(graphData.nodes)
        cells.text(function (d) { return d.value; })
        .attr("contenteditable",function(d){
          if (d.column!="id")
            return true
          else
            return false
        })
        .attr("class","td_edit")
        .attr("id",function(d){
          return d.column;
        })
        .attr("value",function(d){
          return d.value
        })


      //  $('#node-name').html(d.name);
     //$('#node-id').html(d.id)
     cells.exit().remove()
  modal.style.display = "block";

}



// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

/*document.body.addEventListener( 'click', function ( event ) {
  if( event.srcElement.id == 'mySelect' ) {
     $('#mySelect').multiselect({
  
    enableClickableOptGroups: true,
    enableCollapsibleOptGroups: true,
  
  });

  };
} );*/


// Update the current slider value (each time you drag the slider handle)
for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.display === "block") {
      content.style.display = "none";
    } else {
      content.style.display = "block";
    }
  });
}


var color;
 var paths,
    groups,
    groupIds,
    scaleFactor = 1.2,
    polygon,
    centroid;
  var  valueline = d3.svg.line()
      .x(function(d) { return d[0]; })
      .y(function(d) { return d[1]; })
      .interpolate("cardinal-closed")

    var selected_source_node,selected_target_node;
    //We initialise the force layout object here
    var force = d3.layout.force()
        .size([1350, height])
        .charge(function(d){
            var charge = -400;
        if (d.id === 1) charge = 10 * charge;
        return charge;
        })
        .linkDistance(40)
        .friction(0.6)
        .gravity(0.1)
        .on("tick", tick)
       



   var drag = force.drag()
       .on("dragstart", dragstart)
          .on("drag", dragmove)
        .on("dragend", dragend);;

   var graphData;
//var zoom = d3.behavior.zoom().scaleExtent([1, 8]).on("zoom", zoomed);

    var svg = d3.select("#myAreaChart").append("svg")
    .attr("id","container")
        .attr("width", 1350)
        .attr("height", height)
        .attr("border",border)
        .on("mousedown",mousedown)
        .on("mouseup",mouseup)
  // Lasso functions to execute while lassoing
var lasso_start = function() {
  lasso.items()
    .style("fill",null) // clear all of the fills
    .classed({"not_possible":true,"selected":false}); // style as not possible
};

var lasso_draw = function() {
  // Style the possible dots
  lasso.items().filter(function(d) {return d.possible===true})
    .classed({"not_possible":false,"possible":true});

  // Style the not possible dot
  lasso.items().filter(function(d) {return d.possible===false})
    .classed({"not_possible":true,"possible":false});
};

var lasso_end = function() {
  // Reset the color of all dots
  lasso.items()
     .style("fill", function(d) { return color(d.species); });

  // Style the selected dots
  lasso.items().filter(function(d) {return d.selected===true})
    .classed({"not_possible":false,"possible":false})
    .attr("r",7);

  // Reset the style of the not selected dots
  lasso.items().filter(function(d) {return d.selected===false})
    .classed({"not_possible":false,"possible":false})

};      
      // Define the lasso


       // .call(zoom)
         /* .call(d3.behavior.zoom().on("zoom", function () {
        svg.attr("transform", "translate(" + d3.event.translate + ")" + " scale(" + d3.event.scale + ")")
      }))*/


          
   var g=svg.append("g");


  g.append("svg:defs").selectAll("marker")
    .data([{id:"end", opacity:1}, {id:"end-arrow-fade", opacity:0.1}])      // Different link/path types can be defined here
  .enter().append("svg:marker")    // This section adds in the arrows
    .attr("id", function(d){
    	return d.id
    })
    .attr("viewBox", "0 -5 10 10")
    .attr("refX", 18)
    .attr("refY", 0)
    .attr("markerWidth", 9)
    .attr("markerHeight", 9)
    .attr("orient", "auto")
  .append("svg:path")
    .attr("d", "M0,-5L10,0L0,5")
    .attr("opacity",function(d){
    	return d.opacity
    });


 groups = g.append('g').attr('class', 'groups');



    //Create a "g" container element and create selections to reference throughout

    var link = g.append("g").attr('class', 'links').selectAll(".link");
        var edgeweight=g.append("g").attr('class','edgeweight').selectAll(".edgeweight");
     var line=g.append('svg:path')
          .attr('class', 'link dragline hidden')
          .attr("id","hiddenline")
          .attr('d', 'M0,0L0,0')
          //.style('marker-end', 'url(#end)');


    var node = g.append("g").attr('class', 'nodes').selectAll(".node");
    var label=g.append("g").attr("class","nodelabel").selectAll(".label");
    var edgepath=g.append("g").selectAll(".edgepath");
        
   /*var color = d3.scale.linear()
  .domain([0, 9])  
  .range(["blue", "green"]); */
var lasso = d3.lasso()
      .closePathDistance(75) // max distance for the lasso loop to be closed
      .closePathSelect(true) // can items be selected by closing the path?
      .hoverSelect(false) // can items by selected by hovering over them?
      .area(svg) // area where the lasso can be started
      .on("start",lasso_start) // lasso start function
      .on("draw",lasso_draw) // lasso draw function
      .on("end",lasso_end); // lasso end function

document.getElementById("lasso").onclick=(function(){
  //svg.call(lasso);
  // area where the lasso can be started
     d3.select("#myAreaChart") .on("start",null) // lasso start function
      .on("draw",null) // lasso draw function
      .on("end",null);
})




   // Define the div for the tooltip
   var div = d3.select("body").append("div")  
    .attr("class", "tooltip")       
    .style("opacity", 0);

  
   d3.select(window)
  .on('keydown', keydown)
  .on('keyup', keyup);
 // then, create the zoom behvavior



      var zoom = d3.behavior.zoom()
        // only scale up, e.g. between 1x and 50x
        .scaleExtent([1, 8])
        .on("zoom",zoomed);

      // then, call the zoom behavior on the svg element, which will add
      // all of the necessary mouse and touch event handlers.
      // remember that if you call this on the <g> element, the even handlers
      // will only trigger when the mouse or touch cursor intersects with the
      // <g> elements' children!

      function zoomed(){
       
          // and finally, update the <g> element's transform attribute with the
         g.attr("transform",
        "translate(" + zoom.translate() + ")" +
        "scale(" + zoom.scale() + ")"
    );
      }
      svg.call(zoom).on("mousedown.zoom", null)
      .on("dblclick.zoom",null);
  
  var directed=0; //undirected by default


    function update(){
        console.log(directed);
        console.log("INSIDE UPDATE")
        //Create an UPDATE selection by joining data with "link" element selection

        /* edgeweight=edgeweight.data(graphData.links,function(d){
          return d.value;
         })
          edgeweight.append('text')
       .attr("dy", 24)
            .attr("text-anchor","middle")
            //.call(drag)
            .style("text-anchor","middle")
            .style("fill","#555")
            .style("font-family","Arial")
            .style("font-size",12);


         updateweight();*/
        link = link.data(graphData.links);
        console.log(graphData.links)

        //update the id of existing elements (UPDATE SELECTION)
        link.attr("id",function(d){
        	return "link"+d.source.name+d.target.name
        })

        //Access ENTER selection (hangs off UPDATE selection)
        //This represents newly added data that dont have DOM elements
        //so we create and add a "line" element for each of these data
        link
            .enter().append("line")
            .attr("class", "link")
            .attr("id",function(d){
            	// console.log(d.source)
            	 //console.log(d.target)
            	//return +(d.source.name+d.target.name)
            	return("link"+d.source.name+d.target.name)
            })
            //.attr("x1", function(d) { return d.source.x; })
            //.attr("y1", function(d) { return d.source.y; })
            //.attr("x2", function(d) { return d.target.x; })
            //.attr("y2", function(d) { return d.target.y; })
            .style('fill',function (d,i) { //console.log(d.group)
              //console.log(filter());
             console.log(d["\'"+filter_criterion+"\'"]);
             return "black";
            //return color(d.group)
            //return d3.scale.category10(d.group) 
        }) 
            .style("stroke",function(d,i){
              return "black";
            })
            .attr("marker-end", function(d){
              console.log("heelo marker")
              if(directed)
                return "url(#end)";
              else
                return "null";
            })
            .on("mouseover",function(d){
              //alert(d)
               link.style('stroke',function(l){
                    if(d===l)
                        return 'red';
                    else
                      return 'black'
                })
            })
            .on("mouseout",function(d){
              link.style("stroke","black")
            })
           .on("click",function(d){ 
                //alert(d);
                console.log(d)
               
         for(i=0;i<graphData.links.length;i++)
          {
            console.log(graphData.links[i])
            if(graphData.links[i]===d)
               {
                

                graphData.links.splice(i,1);
                //update();
               } 

          }

         

                update();
                updateweight();
            });

        //Access EXIT selection (hangs off UPDATE selection)
        //This represents DOM elements for which there is now no corresponding data element
        //so we remove these from DOM
        link
            .exit().remove();



      edgeweight=edgeweight.data(graphData.links);
      edgeweight.attr("id",function(d,i){return 'edgelabel'+i})
      edgeweight.enter()
            .append("text")
            .text(function (d){ if(d.edgeweight) return d.edgeweight;})
           //.attr("dx", 12)
            .attr("x",function(d){ return d.source.x + (d.target.x - d.source.x)/2; })
            .attr("y",function(d){return d.source.y + (d.target.y - d.source.y)/2;})
             .attr("id",function(d,i){return 'edgelabel'+i})
         //   .text(function(d){if(d.edgeweight) 
           //   return d.edgeweight;})

       

        // updateweight();

         edgeweight.exit().remove();
        //same update pattern for nodes
        console.log("inside update");
        console.log(graphData.nodes);
        console.log(graphData.links);
        node = node.data(graphData.nodes,function(d){return d.name;});
      //  console.log(node);
      node.attr("class",function(d){
            	return "node";
            })
            .attr("id",function(d){
            	return "node"+d.id;
            })
        node.
        enter().append("circle")
            //.attr("class", "node")
            .attr("class",function(d){
            	return "node";
            })
            .attr("id",function(d){
            	return "node"+d.id;
            })
            .attr("r", 12)
            .attr("cx",function(d){
                return d.x;
            }).
            attr("cy",function(d){
                return d.y;
            })
            .style('fill',function (d,i) { //console.log(d.group)
              //console.log(filter());
             console.log(d["\'"+filter_criterion+"\'"]);
             return "blue";
            //return color(d.group)
            //return d3.scale.category10(d.group) 
        }) 
            .attr("stroke-width",1.5)
            /*.on("contextmenu", function(data, index) {
     //handle right click

     //stop showing browser menu
     d3.event.preventDefault();
     //showContextMenu(event)
     /*$("#items > li").click(function(){
      alert("cliekced")
     })*/

            //.on("click", dblclick)
            .on("click",function(d){
               if(d3.event.shiftKey)
                    deletenode(d);
                //if(d3.event.controlKey)
                  //  mousemove(d);
                


                  console.log("MODALL")
                  //btnclick(d);
                 //modal_Open(d)
                // $("#myModal").find(".modal-content").append("<textarea id='textedit' autofocus >"+d.id+"</textarea>");
                  // document.getElementById('myModal').style.display='block';

            })
            .on("mouseover",function(d){
                node.style("stroke-width",function(l){
                    if(d===l)
                        return 4;
                })
                node.style("stroke",function(l){
                  if(d===l)
                    return 'black';
                })
                link.style('stroke',function(l){
                    if(d===l.source || d===l.target)
                        return 'red';
                    else
                      return 'black'
                })
               

                div.transition()    
                .duration(200)    
                .style("opacity", .9);    
            div .html("id:"+d.id + "<br/>" + "name:" + d.name)  
                .style("left", (d3.event.pageX) + "px")   
                .style("top", (d3.event.pageY - 28) + "px");  

            })
            .on("mouseout",function(d){
                node.style("stroke-width",2);
                //link.style("stroke-width",2);
                node.style("stroke","#000");
                link.style("stroke","black");
                  div.transition()    
                .duration(500)    
                .style("opacity", 0); 
            })
            //.call(drag)
            .on("mousedown",mousedown)
            .on("mouseup",mouseup);
         node.exit().remove();
         console.log(graphData.nodes)

      /* edgepaths = svg.selectAll(".edgepath")
            .data(graphData.links)
            .enter()
            .append('path')
           
            .style("pointer-events", "none");*/

           updateweight();
        label=label
                    .data(graphData.nodes,function(d){ return d.name;})

        label.enter()
            .append("text")
            //.text(function (d){ return d.name;})
           //.attr("dx", 12)
            .attr("dy", 24)
            .attr("text-anchor","middle")
            //.call(drag)
            .attr("class","label")
            .style("text-anchor","middle")
            .style("fill","#555")
            .style("font-family","Arial")
            .style("font-size",12)
            .on("click",function(d){
              //alert("hello");
              var result = prompt('Change the name of the node');
              if(result!="")
                d3.select(this).text(result);
        /* for(i=0;i<graphData.nodes.length;i++)
          {
            if(graphData.nodes[i].id==d.id)
               {
                 console.log("link"+graphData.links[i].id);
                graphData.nodes.splice(i,1);
              graphData.nodes.push({
            "id": d.id,
            "name": result,
            "group": d.group});

}
}*/
//update();
                          });

        updatelabel();

        node.exit().remove();
        label.exit().remove();

        d3.selectAll("circle").classed("fixed",false);

        force
            .start();
  lasso.items(d3.selectAll(".node"));


         //groupnodes();
         console.log(filter_criterion)
        /*() if($(".CB").is(':checked')){
           createlegend();
         groupnodes();
         }*/
         if(filter_criterion!=null)
         { 
          //groupnodes();
         createlegend();
         groupnodes();
     }
     SearchAutofill()
       //node_attributes(graphData.nodes);

    };


    function groupnodes(){
      console.log("MICHAEL SCOTTT");
      // count members of each group. Groups with less
  // than 3 member will not be considered (creating
  // a convex hull need 3 points at least)
  console.log(filter_criterion)
  $(".groups").empty();

  groupIds = d3.set(graphData.nodes.map(function(n) { 
    //console.log(+n.g);
    //console.log(+n.eyeColor)
    console.log(n[filter_criterion]);
    return  n[filter_criterion]
    //+ unary operator converts numeric string to number 
  }))
    .values()
    .map( function(groupId) {
      return { 
        groupId : groupId,
        count : graphData.nodes.filter(function(n) { return n[filter_criterion]== groupId; }).length
      };
    })
    .filter( function(group) { return group.count > 2;})
    .map( function(group) { return group.groupId; });
    console.log(groupIds);

  paths = groups.selectAll('.path_placeholder')
    .data(groupIds, function(d) { return d; })
    .enter()
    .append('g')
    .attr('class', 'path_placeholder')
    .style("visibility","visible")
    .append('path')
    .attr('stroke', function(d) { return color(d); })
    .attr('fill', function(d) { return color(d); })
    .attr('opacity', 0);

  console.log(paths);
  paths
    .transition()
    .duration(2000)
    .attr('opacity', 1);

  //groupIds.exit().remove();
  //paths.exit().remove();
  //groups.exit().remove();

    updateGroups();

  // add interaction to the groups
  groups.selectAll('.path_placeholder')
    .call(drag())
      .on('start', group_dragstarted)
      .on('drag', group_dragged)
      .on('end', group_dragended)
      ;

      
    }


// select nodes of the group, retrieve its positions
// and return the convex hull of the specified points
// (3 points as minimum, otherwise returns null)
var polygonGenerator = function(groupId) {
  var node_coords = node
    .filter(function(d) { return d[filter_criterion] == groupId; })
    .data()
    .map(function(d) { return [d.x, d.y]; });
    
  return d3.polygonHull(node_coords);
};



function updateGroups() {
  console.log(paths);
  groupIds.forEach(function(groupId) {
    var path = paths.filter(function(d) { return d == groupId;})
      .attr('transform', 'scale(1) translate(0,0)')
      .attr("id",groupId)
      .attr('d', function(d) {
        polygon = polygonGenerator(d);          
        centroid = d3.polygonCentroid(polygon);

        // to scale the shape properly around its points:
        // move the 'g' element to the centroid point, translate
        // all the path around the center of the 'g' and then
        // we can scale the 'g' element properly
        return valueline(
          polygon.map(function(point) {
            return [  point[0] - centroid[0], point[1] - centroid[1] ];
          })
        );
      });
      console.log(path);
      console.log(path.node())
      console.log(path.node().parentNode)

    d3.select(path.node().parentNode).attr('transform', 'translate('  + centroid[0] + ',' + (centroid[1]) + ') scale(' + scaleFactor + ')');
  });
}

// drag groups
function group_dragstarted(groupId) {
  if (!d3.event.active) simulation.alphaTarget(0.3).restart();
  d3.select(this).select('path').style('stroke-width', 3);
}

function group_dragged(groupId) {
  node
    .filter(function(d) { return d[filter_criterion] == groupId; })
    .each(function(d) {
      d.x += d3.event.dx;
      d.y += d3.event.dy;
    })
}

function group_dragended(groupId) {
  if (!d3.event.active) simulation.alphaTarget(0.3).restart();
  d3.select(this).select('path').style('stroke-width', 1);
}


/*    function directed_arrows(){


    svg.append("svg:defs").selectAll("marker")
    .data(["end"])      // Different link/path types can be defined here
  .enter().append("svg:marker")    // This section adds in the arrows
    .attr("id", String)
    .attr("viewBox", "0 -5 10 10")
    .attr("refX", 15)
    .attr("refY", -1.5)
    .attr("markerWidth", 6)
    .attr("markerHeight", 6)
    .attr("orient", "auto")
  .append("svg:path")
    .attr("d", "M0,-5L10,0L0,5");

link.attr("marker-end","url(#end");

    }*/


function checktree(){
   if (graphData.hasOwnProperty("tree"))
          if (graphData["tree"]===1)
           return 1
          else
            return 0
    else
      return 0

}

function createTree(){
console.log(document.getElementById("treecheckbox").checked)
}
    function tick(e) {
     
        var k = 8 * e.alpha;

       
    //alert(document.getElementById("chargeSlider").value)
    //force
      //  .linkDistance(document.getElementById("linkDistanceSlider").value)

        //force.start()

   //svg.selectAll("circle").transition().ease('linear').duration(10)
    //svg.selectAll("circle").attr("r", document.getElementById("radiusSlider").value);

    //force.linkStrength(0.6)
    // Push sources up and targets down to form a weak tree.
    document.getElementById("treecheckbox").checked
    tree=checktree()
    if (document.getElementById("treecheckbox").checked)
     { 
  // force.charge(-120)
    //    .linkDistance(50)
link
        .each(function(d) { d.source.y -= k, d.target.y += k; }) //for tree
       d3.selectAll("circle").classed("fixed",true);

          }
    else
      {
 //force.charge(-500)
   //     .linkDistance(50)

     //      force .charge(document.getElementById("chargeSlider").value)
    //.linkDistance(document.getElementById("linkDistanceSlider").value)


          }
link
       
        .attr("x1", function(d) { return d.source.x; })
            .attr("y1", function(d) { return d.source.y; })
            .attr("x2", function(d) { return d.target.x; })
            .attr("y2", function(d) { return d.target.y; });

             node.attr("cx", function(d) { return d.x; })
            .attr("cy", function(d) { return d.y; });
     


       /* edgepaths.attr('d', function (d) {
            return 'M ' + d.source.x + ' ' + d.source.y + ' L ' + d.target.x + ' ' + d.target.y;
        });*/

        label.attr("x", function(d){ return d.x; })
                 .attr("y", function (d) {return d.y; });

        edgeweight.attr("x", function(d) { return d.source.x + (d.target.x - d.source.x)/2; })
   .attr("y", function(d) { return d.source.y + (d.target.y - d.source.y)/2; })
 

force.start()
      
        if(filter_criterion)
          updateGroups();

    }

    function dblclick(d) {
        //d3.select(this).classed("fixed", d.fixed = true);
        console.log(this)
    }

    function dragstart(d) {

        d3.select(this).classed("fixed", d.fixed = true);
        console.log(d.id);
        //d.fixed=true;
        force.stop();

    }
  function dragmove(d, i) {
        d.px += d3.event.dx;
        d.py += d3.event.dy;
        d.x += d3.event.dx;
        d.y += d3.event.dy; 
        tick(); // this is the key to make it work together with updating both px,py,x,y on d !
    }

    function dragend(d, i) {
        d.fixed = true; // of course set the node to fixed so the force doesn't include the node in its auto positioning stuff
        tick();
        force.resume();
    }
    function deletenode(d){
      console.log(d)
          console.log("deleting"+d.id)
         //graphData.nodes.pop(d.id);

          nodes=[]
        for(i=0;i<graphData.nodes.length;i++)
          {
            if(graphData.nodes[i].id==d.id)
               {
                graphData.nodes.splice(i,1);
                console.log(graphData.nodes);
                //update();
               } 

          }
        /*graphData.nodes= graphData.nodes.filter(function(l){
                     return l.id!=d.id;
                })
*/
          /*deletedlinks=[]
         for(i=0;i<graphData.links.length;i++)
          {
            if(graphData.links[i].source==d || graphData.links[i].target==d)
               {
                 console.log("link"+graphData.links[i].id);
                 deletedlinks.push(i);
                //graphData.links.splice(i,1);
                //update();
               } 

          }

          for(i in deletedlinks)
            {
                graphData.links.splice(deletedlinks.pop(),1);
             update();
         }*/

        console.log(graphData.links);
        graphData.links= graphData.links.filter(function(l){
                    /*if(d===l.source || d===l.target)
                      {
                       // nodes.push(l.id);
                        console.log("link"+l.id);
                       
                      } */
                      return l.source!==d && l.target!==d;

                })
        console.log(graphData.links)
        update();
        //updateweight();

           for(id in nodes){
            console.log(nodes[id])
            //graphData.links.pop(id);
        }

        //graphData.nodes.pop(d.id);
                    //   update();

    }

     function updatelabel(){
        label.data(graphData.nodes)
        .text(function(d){
            return d.name;
        })
    }

    function updateweight(){
        edgeweight.data(graphData.links)
        .text(function(d){
          if(d.edgeweight)
            return d.edgeweight;
        })
    }
    

    var edges=[]

    function init(){
      //
      var data = {
            "nodes": [
                {
                    "id":1,
                    "name":"1"
                  
                },
                 {"id":2,
                    "name": "abc"
                  },
                  {
                    "id":3,
                    "name":3
                  }
          
            ],
            "links": [
            {"source": "abc" , "target": "1", "edgeweight":"3"},
            {"source": "1" , "target": 3,"edgeweight":"3"}

                
            ]
        };

       // var data={"nodes":[{"id":0,"name":0,"index":0},{"id":2,"name":2,"index":1}],"links":[{"source":0,"target":2,"value":1,"id":3}]}


         graphData = data;
//by default nodes are linked based on index in the list. map the index to ids.
//to link by name change n.id to be n.name
         graphData.links.forEach(function(e) { 
    var sourceNode = graphData.nodes.filter(function(n) { 
      //console.log(n.id === e.source);
      return n.name === e.source; })[0],
    targetNode = graphData.nodes.filter(function(n) { 
       //console.log(n.id === e.target);
      return n.name === e.target; })[0];
    
    edges.push({source: sourceNode, target: targetNode, value: e.Value, edgeweight:e.edgeweight});
    });
       // drag = force.drag()
         // .on("dragstart", dragstart);

        graphData.links=edges;
        force.links(graphData.links);
        force.nodes(graphData.nodes);
        console.log(graphData.links);
        console.log(graphData.nodes);
          color = d3.scale.category20b()
  .range(palette);


        update();
//createMatrix()

    }


    init();




    
    function drawgraph(data){
      console.log(filter_criterion);
      filter_criterion=null;
      console.log(filter_criterion);
        $("#l1").empty();


        /*var data1 = {
            "nodes": [
                {
                    "id":0,
                    "name": 0,
                    "group": 1,
                    "size": 10,
                    "x":169,
                    "y":169
                },
                 {"id":1,
                    "name": 2,
                    "group": 1,
                    "size": 10,
                    "x":169,
                    "y":169}
          
            ],
            "links": [
            {"source": 0 , "target": 1, "value": 1, "id": 1},

                
            ]

        };*/
     

        /*var data1=d3.json("http://localhost:8080/FYP/graphFile.json",function(error,data){
            console.log(error);
            //console.log(data);
            //data1=data;
            console.log(data);
            return data;
        });*/

        console.log(data);
         console.log(document.getElementById("linktype").selectedIndex)
         document.getElementById("linktype").selectedIndex="1";
          console.log(document.getElementById("linktype").value)

        if(!graphData.hasOwnProperty("directed"))
        { 
          document.getElementById("linktype").value//="Undirected"; //undirected
           link.attr("marker-end",null);

         }
        graphData = data;
var edges=[];
         graphData.links.forEach(function(e) { 
    var sourceNode = graphData.nodes.filter(function(n) { 
      //console.log(n.id === e.source);
      return n.id === e.source; })[0],
    targetNode = graphData.nodes.filter(function(n) { 
       //console.log(n.id === e.target);
      return n.id === e.target; })[0];
    
    edges.push({source: sourceNode, target: targetNode, value: e.Value, edgeweight:e.edgeweight});
    });
    console.log(edges)

       // drag = force.drag()
         // .on("dragstart", dragstart);
        graphData.links=edges;
        force.links(graphData.links);
        force.nodes(graphData.nodes);
       if(graphData.directed)
         {directed=1;
          console.log('heee');
          document.getElementById("linktype").value="directed" //directed
         link.attr("marker-end","url(#end");}
       else
         {directed=0;
         link.attr("marker-end",null);}
          //directed_arrows();
           document.getElementById("linktype").value="Undirected"  //undirected
        console.log(graphData.nodes.length);

        node_attributes(graphData.nodes);
        update()
        filter_data();
    }

    function openFile(event){

      $(".groups").empty();
      $(".legend").empty();
      resettable()
     d3.select("#tablecontainer").remove();
      console.log("Opening file");
      //var file=document.getElementById("myFile").files[0];
      var file=event.target.files;
      //console.log(file[0]);
      //console.log(file[0].name+":"+file[0].type+","+file[0].size);
      //console.log(x);
       var x = document.getElementById("myFile").files;
       console.log(x);
       console.log(x[0].size);
       var filename=x[0].name;
       //var path = (window.URL || window.webkitURL).createObjectURL(file[0]);
       //console.log(path);
       document.getElementById("setfilename").text=filename
   
    //init();*/
    var reader = new FileReader();
   var path= reader.readAsDataURL(event.srcElement.files[0]);
   console.log(path);
    
    d3.json(filename,function(error,data){
        console.log(filename);
            console.log(error);
            //console.log(data);
           console.log(validateJSONnodes(data.nodes));
            console.log(validateJSONlinks(data.links));

            if(Boolean(validateJSONnodes(data.nodes)) && Boolean(validateJSONlinks(data.links)) )
              drawgraph(data);
            else
              alert("INVALID JSON");

            //data1=data;
           /* if(validateJSONnodes(data.nodes) && validateJSONlinks(data.links))
              init(data);
            else
              alert("INVALID JSON FORMAT");*/
            console.log(data);
            //if(validateJSON(data))
              //init(data)
            //else
              //alert("INVALID");
            //return data;
        });
  
  }
    //init();

  function validateJSON(data){
    console.log("VALIDATING")
    for(item in data){
      //for(subitem in data[item])
      if(data[item].hasOwnProperty("id"))
        console.log(data[item]);
    }
    //nodes=null;
    for(item in data){
      console.log(item);
      if(!item["id"]){
        console.log("id")
        //return false;
      }
      if(!item["name"])
      {
        console.log("name")
      }
      if(!item["group"])
        console.log("name");
    }

    for(link in links){
//check if they all contain source,target and id.

    }
   // return true;

  }

  function validateJSONnodes(data){
    console.log("VALIDATING")
    for(item in data){
      console.log(data[item]);
      if(((data[item].hasOwnProperty("name")) && (data[item].hasOwnProperty("id"))))
        {
          console.log(data[item]);
          //continue;
        }
      else
        return Boolean(false);
  
    }
    return Boolean(true);
  }


 function validateJSONlinks(data){
    console.log("VALIDATING")
    for(item in data){
      //for(subitem in data[item])
      console.log(data[item]);
      if(Boolean((data[item].hasOwnProperty("source")) && (data[item].hasOwnProperty("target"))))// && (data[item].hasOwnProperty("id"))))
        {
          console.log(data[item]);
        }
      else 
        return Boolean(false);
    }
    return Boolean(true);
  }
    d3.select("svg").on("dblclick", function() {

        //randomly select a (currently existing) node that our new node will link to
        var coords=d3.mouse(this);
        console.log(coords[1]+","+coords[1])
        var sourceNodeId = Math.floor(Math.random() * (graphData.nodes.length-1));

        //if there are n nodes currently (before we add a new one, below) then
        //the new target node will be the (n+1)th node with an id of n (zero-indexing)
        //var newNodeId = graphData.nodes.length;
        var newNodeId;
         for(var i=0;i<graphData.nodes.length;i++)
        {
            if(i==graphData.nodes.length-1)
                {
                    console.log(graphData.nodes[i].id+1);
                    newNodeId=graphData.nodes[i].id+1;
                }

        }
        //setting new id correctly
        newNodeId=graphData.nodes[graphData.nodes.length-1].id
        newNodeId=newNodeId+1
        console.log()
        // if there are currently n links (before we add a new one, below) then
        // the new link will have an id of n (first link has an id of 0)
        var linkId = graphData.links.length;

        /*graphData.links.push({
            "source": sourceNodeId , "target": newNodeId, "value": 1, "id": linkId
        });*/

        graphData.nodes.push({
            "id": newNodeId,
            "name": newNodeId
        });

        update();

    });

//var linefunction=svg.append("svg:path").attr('class', 'link dragline hidden')
  //        .attr('d', 'M0,0L0,0')
       
var selected_source_node;
function mousedown(d) {
  if( document.getElementById('myonoffswitch').checked)
    {
       var p = d3.mouse( this);

    svg.append( "rect")
    .attr({
        rx      : 6,
        ry      : 6,
        class   : "selection",
        x       : p[0],
        y       : p[1],
        width   : 0,
        height  : 0
    })

    svg.on("mousemove",function(){
      var s = svg.select( "rect.selection");

    if( !s.empty()) {
        var p = d3.mouse( this),
            d = {
                x       : parseInt( s.attr( "x"), 10),
                y       : parseInt( s.attr( "y"), 10),
                width   : parseInt( s.attr( "width"), 10),
                height  : parseInt( s.attr( "height"), 10)
            },
            move = {
                x : p[0] - d.x,
                y : p[1] - d.y
            }
        ;

        if( move.x < 1 || (move.x*2<d.width)) {
            d.x = p[0];
            d.width -= move.x;
        } else {
            d.width = move.x;       
        }

        if( move.y < 1 || (move.y*2<d.height)) {
            d.y = p[1];
            d.height -= move.y;
        } else {
            d.height = move.y;       
        }
       
        s.attr( d);

            // deselect all temporary selected state objects
        d3.selectAll( '.node').classed( "selected", false);
        d3.selectAll( '.link').classed( "selected", false);
radius=svg.selectAll("circle").attr("r")
console.log(radius)
        d3.selectAll( '.node').each( function( state_data, i) {
          console.log(state_data)
            if (!d3.select( this).classed( "selected") &&
              state_data.x-radius>=d.x && state_data.x+radius<=d.x+d.width && 
                state_data.y-radius>=d.y && state_data.y+radius<=d.y+d.height)
                    // inner circle inside selection frame
       {

                d3.select( this)
                .classed( "selection", true)
                .classed( "selected", true)
                .style("r",18)
            }
        });

          d3.selectAll( '.link').each( function( state_data, i) {
            if(!state_data)
              return
          console.log(state_data.source)
            if (!d3.select( this).classed( "selected") &&
              d3.select("#node"+state_data.source.id).classed("selected") && d3.select("#node"+state_data.target.id).classed("selected"))
                    // inner circle inside selection frame
       {
         //alert("inside")
                d3.select( this)
                .classed( "selection", true)
                .classed( "selected", true)
                .style("stroke-width",4)
            }

        });


    }
    svg.on( "mouseup", function() {
       // remove selection frame
    console.log("HEHEHEH")
   var nodes_delete=[]
   d3.selectAll(".node").each(function(d,i){
    if (d3.select( this).classed("selected"))
{
      console.log("not selected") 
      console.log(d)
      nodes_delete.push(d)

}
         })
   console.log(nodes_delete)
   
    svg.selectAll( "rect.selection").remove();
    console.log(d3.selectAll("circle.node.selection.selected"))

    //d3.selectAll("circle").classed("selected",false).remove()
    d3.selectAll("circle").style("r",12)
    console.log(d3.selectAll("circle").classed("selected",false))

    d3.selectAll("line").style("stroke-width",1.5)
        // remove temporary selection marker class
    d3.selectAll( '.node').classed( "selection", false);
    d3.selectAll('.link').classed("selection",false)

    for(var i=0;i<nodes_delete.length;i++)
      deletenode(nodes_delete[i])

})

    })
  }
    var m = d3.mouse(this);
    console.log("start"+m[0]+","+m[1]+ ","+d.id)
    selected_source_node=d;
    console.log(d);
    svg.on("mousemove",mousemove)
        // line.style("stroke-width","0")

    line.classed('hidden', false)
        .attr('d', 'M' + m[0] + ',' + m[1] + 'L' + m[0] + ',' + m[1]);
   /* line=svg.append("path")
                .attr("x1",m[0])
                .attr("y1",m[1])
                .attr("x2",m[0])
                .attr("y2",m[1])
                .style("stroke", "#ccc");*/
//linefunction.classed("hidden",false) .attr('d', 'M' + d.x + ',' + d.y + 'L' + d.x + ',' + d.y);



     svg.on("mousemove",mousemove);


    /*svg.on("mouseup", function(){
      mouseup(m[0],m[1])
    });*/
}

function mousemove(d) {
    var m = d3.mouse(this);
    //console.log("MOUSEMOVE");
   // linefunction.attr('d', 'M' + d.x + ',' + d.y + 'L' + m[0] + ',' + m[1]);
    /*line.attr("x2", m[0]-1)
        .attr("y2", m[1]-1)
        .style("stroke", "#ccc");
*/
console.log('moving');
line.attr('d', 'M' + selected_source_node.x + ',' + selected_source_node.y + 'L' +m[0] + ',' + m[1]);
   // linefunction.classed("hidden",true)
   svg.on("mouseup",mouseup)
}


function mouseup(d) {
  //console.log("MOUSEUP");
      /*var m = d3.mouse(d3.event.currentTarget);
        line = svg.append("line")
        .attr("x1", x)
        .attr("y1", y)
        .attr("x2", m[0])
        .attr("y2", m[1])
        .style("stroke", "#ccc");*/
        console.log(d3.mouse(d3.event.currentTarget))
        console.log(d);
        console.log("mouseup");
        selected_target_node=d
        if(!selected_source_node)
        {
          //alert("non")
            return;
        }
        console.log(selected_target_node);
        
        svg.on("mousemove",null)
        var m=d3.mouse(this)
 line.classed("hidden", true);


        console.log("end"+m[0]+","+m[1]+","+d.id)
        if(selected_source_node!==selected_target_node)
          {console.log(selected_source_node.id);
        console.log(selected_target_node.id)
            graphData.links.push({
                "source":selected_source_node,
                "target":selected_target_node,
                "id":graphData.links.length+1
            })
        }
        console.log(graphData.links)
        update();

  //console.log("end"+m[0]+""+m[1])
   
}


//json format is different from graphdata.links. graphdata.links
//has node pos details which are not needded in the json file.
//every time graphdata.links is updated update json file also
function updateJSONLINKS(){

}
// only respond once per keydown
let lastKeyDown = -1;
function keydown(){
  //d3.event.preventDefault();
  if (lastKeyDown !== -1) return;
  lastKeyDown = d3.event.keyCode;

  // ctrl
  if (d3.event.keyCode === 17) {
    //alert("helo")

    node.call(drag);
    label.call(drag);
    drag.on("dragstart", dragstart);
    drag.on("dragmove",dragmove);
    drag.on("dragend",dragend);
    svg.classed('ctrl', true);

}
}

function keyup() {
  lastKeyDown = -1;

  // ctrl
  if (d3.event.keyCode === 17) {
    node.on('.drag', null);
    label.on(".drag",null);
    drag.on("dragstart",null);
     drag.on("dragmove",null);
    drag.on("dragend",null);
    svg.classed('ctrl', false);
    
  }
}

var dragOnOff = d3.select("#drag");

//var dragCallback = node.property('__onmousedown.drag')['_'];

var draggable = true;

dragOnOff.on("click", function () {
    console.log("hello");
    node.on('mousedown.drag', draggable ? null : dragCallback);
    this.value = 'switch drag to ' + draggable;
    draggable = !draggable;
});

document.getElementById('submitsearch').onclick = function()
{
    var searchnode=document.getElementById('searchbox').value;
    console.log("Search node"+searchnode);
   
    //console.log("hello");//console.log(graphData.nodes[i].id+1);
                    //newNodeId=graphData.nodes[i].id+1;
    link.style('stroke-width', function(l) {
               if (searchnode == l.source || searchnode == l.target)
                   {
                    console.log("source"+l.source);
                    console.log("target"+l.target);
                    return 4;


                }
              else
                 {  
                     console.log("source"+l.source);
                    console.log("target"+l.target);
                    return 2;
                 }
    });


                

        
};


 function link_type() {
  //alert("HELLO")
  console.log(document.getElementById("linktype").value)
  if(document.getElementById("linktype").value==="directed")
    {directed=1;
   link.attr("marker-end","url(#end");}
  else 
     {
       directed=0;
       link.attr("marker-end",null);
     }

     update();
}
//node_attributes();
function node_attributes(data){
  var node_attr=[];//gets all keys
  for(item in data){
    for(subitem in data[item]){
        console.log(subitem+":"+data[item][subitem]);
        node_attr.push(subitem);
      }
    }
    console.log(node_attr.length);
    console.log(data.length);
    if(node_attr.length % data.length===0)  //all elements contain same number of attributes
      console.log("OKK")
    //console.log(node_attr[0]);
    //node_attr=new Set(node_attr);
    console.log(node_attr.size);
    //set which represents the attributes to be ignored
    var prop=new Set(["id","name","index","weight","x","y","px","py","selected","possible","fixed"]);
    var validList = node_attr.filter((item) => {
  return !prop.has(item);
})

    console.log(validList.length);
    validList=new Set(validList);
    console.log(validList.size);
    console.log(validList);

  console.log(Object.keys(data))
  //build_checklist(validList);
  attrList(validList);
  multipleDropdown(validList)
  }

var filter_criterion;

function build_checklist(validList){
console.log("checkbox");
  /*var checkbox=document.createElement("input");
  checkbox.type="checkbox";
  checkbox.id="cb";
  checkbox.value="test";
  checkbox.checked=false;*/
  var prev=document.getElementsByClassName("cb");
  console.log(prev.length)
 while(prev[0])
    {
      var id=prev[0].id;
      console.log(id);
      var label=document.getElementById("labelfor"+id);
      console.log(prev[0])
      prev[0].parentNode.removeChild(prev[0]);
      label.parentNode.removeChild(label);
      //prev[i].parentNode.removeChild(prev[i]);
      //console.log(label);
     
      //var label=document.getElementById(label);
      //label.parentNode.removeChild(label)
    }
    $('br', "#append").remove();
   // prev.parentNode.removeChild(prev);
 var iterator1 = validList.values()
 if(!iterator1)
    return;
   
   for(var i=0;i<validList.size;i++)
   {
   // console.log(iterator1.next().value);
   var item=iterator1.next().value;
  /* var div_ele=document.createElement("div");
   div_ele.className="radiolist";*/
    var checkbox=document.createElement("input");
     checkbox.type="radio";
  checkbox.id="cb"+i;
  checkbox.className="cb";
  checkbox.value=item;
  checkbox.name="attr";
  document.getElementById('append').appendChild(checkbox);
  var label=document.createElement('label');
  label.htmlFor=checkbox.id;
  label.id="labelfor"+checkbox.id;
  label.appendChild(document.createTextNode(item));
   
    document.getElementById('append').appendChild(label);
    document.getElementById('append').appendChild(document.createElement("br"));    
   }
 
 document.getElementById('append').onclick=function(){
 

  //alert("checled");
   for(i=0;i<document.getElementsByClassName('cb').length;i++){
    if(document.getElementsByClassName("cb")[i].checked){
      filter_criterion=document.getElementsByClassName("cb")[i].value;
      console.log(filter_criterion);
      break;
    }
   }
   console.log("AT build_checklist ")
   createlegend();
   filter();
 }
 console.log("OUUTT")

}

var ordinal;
function createlegend(){
	console.log("AT createlegend")
  var legendset=new Set();
  for(var item in graphData.nodes)
{
  for(var prop in item)
   { console.log(graphData.nodes[item][filter_criterion]);
      legendset.add(graphData.nodes[item][filter_criterion])
   }
}
 console.log(legendset);
 console.log(legendset.size);
 console.log(legendset.values())
 var arr = Array.from(legendset.values());
 
  var hasUndefined;
  arr= arr.filter(function(el) { 
  	console.log(el);
  	if(el==undefined)
  		{console.log("UNDDEFINED")
  	hasUndefined=true;

  }

 	return el});

if(hasUndefined)
	arr.push("undefined")

console.log(arr)

var active_link = "0"; //to control legend selections and hover
var legendClicked; //to control legend selections
if(document.getElementById("legend"))
  svg.selectAll(".legend")
      .data([]).exit().remove();
  var legend = svg.selectAll(".legend")
      .data(arr)
    .enter().append("g")
      .attr("class", function (d) {
        
        return "legend";
      })
      .attr("transform",function(d, i) { return "translate(-750," + i * 20 + ")";});

 legend.append("rect")
      .attr("x", width - 18)
      .attr("width", 18)
      .attr("height", 18)
      .style("fill", color)
      .attr("id", function (d, i) {
      	if(typeof(d)=="number")
      		return "id"+d;
        else if(typeof(d)=="undefined")
        	return "id"+"undefined"+i;
        else
        	return "id" + d.replace(/\s/g, '');
      })
     
      .attr("enabled","true")
      .on("mouseover",function(){        

        if (active_link === "0") d3.select(this).style("cursor", "pointer");
        else {
          if (active_link.split("class").pop() === this.id.split("id").pop()) {
            d3.select(this).style("cursor", "pointer");
          } else d3.select(this).style("cursor", "auto");
        }
      })
      .on("click",function(d){
        console.log(d);
        console.log(d3.select(this).attr("id"))
        if(d3.select(this).attr("enabled")=="true")
          {
            console.log("HERE")
            d3.select(this).attr("enabled","false");
            d3.select(this).style("opacity",0.5);
            filtering(d,"hidden")
       /* d3.selectAll(".path_placeholder").transition().duration(500).style("visibility",function(o,i){
            if(o==d)
              return "hidden";
      })*/
          }
        else
          {
            console.log("THERE")
            d3.select(this).attr("enabled","true");
              d3.select(this).style("opacity",1);
              filtering(d,"visible");
                  
       /* d3.selectAll(".path_placeholder").transition().duration(500).style("visibility",function(o,i){
            if(o==d)
              return "visible";
      })*/
          }

      })
      .on("dblclick",null);
        

      
                          
                                
 
      legend.append("text")
      .attr("x", width - 24)
      .attr("y", 9)
      .attr("dy", ".35em")
      .style("text-anchor", "end")
      .text(function(d) { return d; });
 /*var iterator1=legendset.values();
 var list=document.getElementById("l1");
if(list)
  list.parentNode.removeChild(list);
 list=document.createElement("ul");
 list.setAttribute('id',"l1");
 list.setAttribute("class","legend-labels")


for(var i=0;i<legendset.size;i++)
{
  var entry=document.createElement('li');
var span=document.createElement("span");
var item=iterator1.next().value;
var checkboxitem=document.createElement("input");
checkboxitem.className="checklist";
checkboxitem.type="checkbox";
checkboxitem.value=item;
checkboxitem.name=item;
checkboxitem.checked="true";
checkboxitem.onclick=function(){
  console.log("CLICK")
 filterGraph();
}

var text=document.createTextNode(item);
span.style.background=color(item);
entry.appendChild(checkboxitem);
entry.appendChild(text);
entry.appendChild(span);

list.appendChild(entry);
}
var parent=document.getElementById("legend");
 parent.appendChild(list);*/





}

function filter(){
 /*for(i=0;i<document.getElementsByClassName('cb').length;i++){
    if(document.getElementsByClassName("cb")[i].checked){
      filter_criterion=document.getElementsByClassName("cb")[i].value;
      console.log(filter_criterion);
      //break;
    }
    createlegend();*/
console.log("FILTERR");
  for(item in graphData.nodes)
      console.log(filter_criterion+":"+graphData.nodes[item][filter_criterion]);

/*node.style("fill",function(d,i){
  console.log(d["\'"+filter_criterion+"\'"]);å
})*/
/*var entry=document.createElement('li');
var span=document.createElement("span");
var text=document.createTextNode("HELLO");
span.appendChild(text);
span.style.background="red";
entry.appendChild(span);
list.appendChild(entry);*/
//ele.appendChild(document.createTextNode("FOUR"));
//ulist.appendChild(ele);
//legendlist.appendChild(ulist);
//legendlist.append(ulist);

//get the distinct values of that attribute
/*var legendset=new Set();
for(var item in graphData.nodes)
{
  for(var prop in item)
   { console.log(graphData.nodes[item][filter_criterion]);
      legendset.add(graphData.nodes[item][filter_criterion])
   }
}
for(var i=0;i<legendset.size;i++)
{
  var entry=document.createElement('li');
var span=document.createElement("span");
var text=document.createTextNode(legendset[i]);
span.appendChild(text);
span.style.background=color(legendset[i]);
entry.appendChild(span);
list.appendChild(entry);
}*/
var p=d3.selectAll("circle");
p.style("fill",function(d,i){
  //var str="gender";
  //console.log(d['\"'+str+'\"']);
 //console.log(d);
 if(!d.hasOwnProperty(filter_criterion))
 {
 	return color("undefined")
 }
 for(var property in d)
  if(filter_criterion===property)
    {console.log(color(d[property]));
      break;


    }
 
  return color(d[property]);
});

  //console.log(legendset);
  console.log("inside filter");
  groupnodes();
}


/*var saveData = (function () {
  console.log("hhh")
    var a = document.createElement("a");
    document.body.appendChild(a);
    a.style = "display: none";
    return function (data, fileName) {
        var json = JSON.stringify(data),
            blob = new Blob([json], {type: "octet/stream"}),
            url = window.URL.createObjectURL(blob);
        a.href = url;
        a.download = fileName;
        a.click();
        window.URL.revokeObjectURL(url);
    };
}());

var data = { x: 42, s: "hello, world", d: new Date() },
    fileName = "my-download.json";

saveData(data, fileName);*/

function downloadBlob(e) {
  //extract();
  var jsonse = JSON.stringify(extract());
var blob = new Blob([jsonse], {type: "application/json"});
 // var blob = new Blob([graphData], {type : 'octey/stream'});
  var url = URL.createObjectURL(blob);
  e.href = url;
  e.download = 'test.json'
}

// Below are the functions that handle actual exporting:
// getSVGString ( svgNode ) and svgString2Image( svgString, width, height, format, callback )
function save(){
  //remove the dragline before saving as image
  var element=document.getElementById("hiddenline");
  element.parentNode.removeChild(element);
    var svgString = getSVGString(svg.node());
    svgString2Image( svgString, 2*width, 2*height, 'png', save ); // passes Blob and filesize String to the callback

    function save( dataBlob, filesize ){
        saveAs( dataBlob, 'D3 vis exported to PNG.png' ); // FileSaver.js function
    }


    //append dragline back
    line=svg.append('svg:path')
          .attr('class', 'link dragline hidden')
          .attr("id","hiddenline")
          .attr('d', 'M0,0L0,0')

}
function getSVGString( svgNode ) {
    svgNode.setAttribute('xlink', 'http://www.w3.org/1999/xlink');
    var cssStyleText = getCSSStyles( svgNode );
    appendCSS( cssStyleText, svgNode );

    var serializer = new XMLSerializer();
    var svgString = serializer.serializeToString(svgNode);
    svgString = svgString.replace(/(\w+)?:?xlink=/g, 'xmlns:xlink='); // Fix root xlink without namespace
    svgString = svgString.replace(/NS\d+:href/g, 'xlink:href'); // Safari NS namespace fix

    return svgString;

    function getCSSStyles( parentElement ) {
        var selectorTextArr = [];

        // Add Parent element Id and Classes to the list
        selectorTextArr.push( '#'+parentElement.id );
        console.log(selectorTextArr);
        for (var c = 0; c < parentElement.classList.length; c++)
                if ( !contains('.'+parentElement.classList[c], selectorTextArr) )
                {
                   selectorTextArr.push( '.'+parentElement.classList[c] );

                }
       //selectorTextArr=selectorTextArr.splice(2,3);
    
        // Add Children element Ids and Classes to the list
        var nodes = parentElement.getElementsByTagName("*");
        for (var i = 0; i < nodes.length; i++) {
            var id = nodes[i].id;
            if ( !contains('#'+id, selectorTextArr) )
                selectorTextArr.push( '#'+id );

            var classes = nodes[i].classList;
            for (var c = 0; c < classes.length; c++)
                if ( !contains('.'+classes[c], selectorTextArr) )
                    selectorTextArr.push( '.'+classes[c] );

       // console.log(selectorTextArr);
        }
        //manually pushing .groups otherwise it results in opaque ibjects
        selectorTextArr.push('.'+"groups")
        console.log(selectorTextArr.length)
       selectorTextArr.splice(4,2);
        for(var i=0;i<selectorTextArr.length;i++)
        {
          //if(selectorTextArr[i]==".link" || selectorTextArr[i]==".dragline"||selectorTextArr[i]==".hidden") 
            //selectorTextArr.splice(i);
            //selectorTextArr.splice(i);
          console.log(selectorTextArr[i])
        }
        console.log(selectorTextArr);
        // Extract CSS Rules
        var extractedCSSText = "";
        for (var i = 0; i < document.styleSheets.length; i++) {
            var s = document.styleSheets[i];
            
            try {
                if(!s.cssRules) continue;
            } catch( e ) {
                    if(e.name !== 'SecurityError') throw e; // for Firefox
                    continue;
                }

            var cssRules = s.cssRules;
            for (var r = 0; r < cssRules.length; r++) {
                if ( contains( cssRules[r].selectorText, selectorTextArr ) )
                    extractedCSSText += cssRules[r].cssText;
            }
        }
        console.log(extractedCSSText)

        return extractedCSSText;

        function contains(str,arr) {
            return arr.indexOf( str ) === -1 ? false : true;
        }

    }

    function appendCSS( cssText, element ) {
        var styleElement = document.createElement("style");
        styleElement.setAttribute("type","text/css"); 
        styleElement.innerHTML = cssText;
        var refNode = element.hasChildNodes() ? element.children[0] : null;
        element.insertBefore( styleElement, refNode );
    }
}


function svgString2Image( svgString, width, height, format, callback ) {
    var format = format ? format : 'png';

    var imgsrc = 'data:image/svg+xml;base64,'+ btoa( unescape( encodeURIComponent( svgString ) ) ); // Convert SVG string to data URL

    var canvas = document.createElement("canvas");
    var context = canvas.getContext("2d");

    canvas.width = width;
    canvas.height = height;

    var image = new Image();
    image.onload = function() {
        context.clearRect ( 0, 0, width, height );
        context.drawImage(image, 0, 0, width, height);

        canvas.toBlob( function(blob) {
            var filesize = Math.round( blob.length/1024 ) + ' KB';
            if ( callback ) callback( blob, filesize );
        });

        
    };

    image.src = imgsrc;
}

/*remove the position info from JSON before exporting it*/
function extract(){
      var newJSON={"nodes":[],
      "links":[]};

     var newgraph=JSON.parse(JSON.stringify(graphData));
      //delete newgraph.nodes["px"]
  /*for(node in newgraph.nodes)
        {//delete newgraph.nodes[node]["px"];
      //delete newgraph.nodes[node]["py"];
      delete newgraph.nodes[node]["x"];
      delete newgraph.nodes[node]["y"];
}
*/
//console.log(newgraph.nodes);


      console.log(newJSON);
      //var myObj = {"test": {"key1": "value", "key2": "value"}}
      //delete myObj.test["key2"];
      //console.log(myObj)
      //newgraph=graphData;
      console.log(graphData)
      for(var node in newgraph.nodes){
      delete newgraph.nodes[node].py;
      delete newgraph.nodes[node].px;
      delete newgraph.nodes[node].x;
      delete newgraph.nodes[node].y;
      delete newgraph.nodes[node].weight;
      delete newgraph.nodes[node].fixed;  //node postion fixed or not
      delete newgraph.nodes[node].possible;
      delete newgraph.nodes[node].selected;
    }

     for( var links in newgraph.links){
     
      newgraph.links[links]["source"]=newgraph.links[links]["source"]["id"];
      newgraph.links[links]["target"]=newgraph.links[links]["target"]["id"];
      //newgraph.links[links]["source"]=source;
      //newgraph.links[links].target=target;
      //delete newgraph.links[links].x;
      //delete newgraph.links[links].y;
    }

  console.log(newgraph);

  var jsonse = JSON.stringify(newgraph);

  console.log(jsonse)

/*
      for(node in graphData.nodes)
          {newJSON.nodes.push({
            "id":graphData.nodes[node]["id"],
            "name":graphData.nodes[node]["name"],
            "group":graphData.nodes[node]["group"]
          });
 
      }
*/

   /*   for(link in graphData.links)
         { newJSON.links.push({
          "id":graphData.links[link]["id"],
          "source":graphData.links[link]["source"]["id"],
        "target":graphData.links[link]["target"]["id"],
        "value":graphData.links[link]["value"]

      });
    }

    console.log(newJSON)*/
    return newgraph;
  }

function closeModal(){
  var span = document.getElementsByClassName("close")[0];
span.onclick = function() {
    document.getElementById('myModal').style.display = "none";
}

}

function renamenode(){
 // alert("TEXT EDITs")
}

// Get the modal


// Get the button that opens the modal
//var btn = document.getElementById("myBtn")
//.on("click",btnclick);

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal 
var modal_clickednode;
function btnclick(d) {
  modal_clickednode=d; 
   console.log("MODAL")
   console.log(d);
   var modal = document.getElementById('myModal');
    modal.style.display = "block";
    document.getElementById("nodename").value=d.name;
    //document.getElementById("nodevalue").value=d.id;


    createattrList();
   
   document.getElementById("nodeprop").onchange=function(){
      var selected=this.value;
      console.log(selected);
     graphData.nodes.filter(function(n) { if(d.name===n.name) {
    
    document.getElementById("attrvalue").value=d[selected];
    }
     })
    }
   console.log(document.getElementById('nodeprop').options[document.getElementById('nodeprop').selectedIndex].value);
    console.log("CHANGEE");
  /*graphData.nodes.filter(function(n) { if(d.name===n.name) {
    n.name=document.getElementById("nodename").value;
    console.log(n);
    update();}
     })*/

}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (!e) var e = window.event;
    if (e.which) 
      rightclick = (e.which == 3);
    else if (e.button) 
      rightclick = (e.button == 2);
    //alert('Rightclick: ' + rightclick);
    if (event.target != modal) {
        modal.style.display = "none";
    }
}

function changedName(d){
  console.log(d);
  console.log("new",document.getElementById("nodename").value);

  
}


function updatenodeattr(id,column){
  //alert("HUUUU")

   graphData.nodes.filter(function(k){
          if (k.id==id)
           { k[column]=document.getElementById(column).innerHTML
            return
           }

        })
      
  console.log(a)
  var rows=document.getElementsByClassName("td_edit")
  for(i=0;i<rows.length;i++)
    console.log(rows[i].id + ""+rows[i].value)
  //console.log("new",document.getElementById("nodename").value);
  //console.log("new",document.getElementById("nodeid").value);
  //console.log("old",modal_clickednode.name);
  //console.log("old",modal_clickednode.id);
  
  //var newname=document.getElementById("nodename").value;
  //var newid=document.getElementById("nodeid").value;
  //var name_exists=graphData.nodes.filter(function(n){
    //return n.name==newname;
  //})
 /* var id_exists=graphData.nodes.filter(function(n){
    return n.id==newid;
  })*/
  
  /*console.log(name_exists)
  console.log(document.getElementById("attrvalue").value);
 //console.log(id_exists);
 

    graphData.nodes.filter(function(n) { if(modal_clickednode.name===n.name) {
      if(name_exists=="")
      {
        if(newname=="")
          alert("NAME CANNOT BE EMPTY");
        else 
          n.name=newname;
      }
      else
      {
        if(modal_clickednode.name==newname)
          console.log("HHHH");
        else
          alert("Name already exists")
      }
    //n[document.getElementById('nodeprop').options[0].value]=document.getElementById("attrvalue").value;
    console.log(n[document.getElementById('nodeprop').options[document.getElementById('nodeprop').selectedIndex].value])
    n[document.getElementById('nodeprop').options[document.getElementById('nodeprop').selectedIndex].value]=document.getElementById("attrvalue").value;
    console.log(n);
    update();}
     })
  */
 

}


   function createattrList() {
     resetdropdown();
     console.log("ATTR LISR");
       var cbox=document.getElementById("append").getElementsByTagName("label");
       var len=cbox.length;

       for (var i=0; i<len; i++) {
         console.log(cbox[i].textContent);
        var item=document.createElement("option");
        item.value=cbox[i].textContent;
        item.id="item"+i;
        item.textContent=cbox[i].textContent;

          document.getElementById('nodeprop').appendChild(item);
    }

console.log(document.getElementById('nodeprop').options[0].value)
     graphData.nodes.filter(function(n) { if(modal_clickednode.name===n.name) {
    
    document.getElementById("attrvalue").value=n[document.getElementById('nodeprop').options[0].value];
    }
     })

        }

  function resetdropdown(){
    var dropdownlist=document.getElementById("nodeprop");
    console.log(dropdownlist.length)
    while (dropdownlist.length > 0) {
    dropdownlist.remove(dropdownlist.length-1);
}
  }

 function dropdownSelect(value){
  //var selected=document.getElementById("nodeprop").options[document.getElementById("nodeprop").selectedIndex].text;
  console.log(value)
 }

function filter_data(){
  console.log("hello")
  resetdropdown();
       var cbox=document.getElementById("append").getElementsByTagName("label");
       var len=cbox.length;

       for (var i=0; i<len; i++) {
         console.log(cbox[i].textContent);
        var item=document.createElement("option");
         item.id="item"+i;
        item.value=cbox[i].textContent;
       
        item.textContent=cbox[i].textContent;


          document.getElementById('filter').appendChild(item);
          
}
}

//commented out filtergraph call ->see filtering
function filterGraph(){
  var cboxes = document.getElementsByClassName('checklist');
    var len = cboxes.length;


    for (var i=0; i<len; i++) {
        
        //console.log(i + (cboxes[i].checked?' checked ':' unchecked ') + cboxes[i].value);
        if(cboxes[i].checked)
          {console.log(cboxes[i].value)
            var lvisibility=cboxes[i].checked ? "visible" : "hidden";
            console.log(lvisibility);
            filtering(cboxes[i].value,"visible");
           d3.selectAll(".path_placeholder").style("visibility",function(o,i){
            if(o==cboxes[i].value)
              return "visible"
          });
      }
          else
            {filtering(cboxes[i].value,"hidden")
        d3.selectAll(".path_placeholder").style("visibility",function(o,i){
            if(o==cboxes[i].value)
              return "hidden"
          });
        
        }
       
    }
}

function filtering(filter_condition,aVisibility){
  node.style("visibility", function (o,i) {
            var lOriginalVisibility = $(this).css("visibility");
            console.log(filter_condition);
            console.log(o[filter_criterion]);
            console.log(aVisibility);
            console.log(lOriginalVisibility);
            console.log(o.name)
            console.log(o[filter_criterion] === filter_condition ? aVisibility : lOriginalVisibility);
            console.log(d3.select(d3.selectAll(".label")[0][i]));
            d3.select(d3.selectAll(".label")[0][i]).style("visibility",o[filter_criterion] === filter_condition ? aVisibility : lOriginalVisibility)
            return o[filter_criterion] === filter_condition ? aVisibility : lOriginalVisibility;
        });
 link.style("visibility", function (o, i) {
            var lHideNode = true;
            //console.log(o);
             var s;
             node.filter(function(d){
                if(d.name===o.source.name)
                 s=( $(this).css("visibility"));
              })
             var t;
             node.filter(function(d){
              if(d.name=== o.target.name)
                t=( $(this).css("visibility"));
              })
             if(s==="visible" && t==="visible")
              lHideNode=true;
            if(s==="hidden" || t==="hidden")
              lHideNode=false;

            /*node.each(function (d, i) {
              console.log(d.name);
              //console.log(o.source.name);
              //console.log(o.target.name);
              var s=node.filter(function(d){
                if(d.name===o.source.name)
                  console.log( $(this).css("visibility"));
              })
             var t= node.filter(function(d){
              if(d.name=== o.target.name)
                console.log( $(this).css("visibility"));
              })
            // console.log(s);
            // console.log(t);
                if (d.name === o.source.name || d.name === o.target.name) {
                  console.log("INNNN")
                  console.log($(this))
                    if ($(this).css("visibility") === "visible") {
                      //console.log($(this).css("visibility"))
                      console.log(d.name+"VISIBLE"+d.gender)
                        lHideNode = false;
                        // we need show the text for this circle
                        //console.log(d3.select(d3.selectAll(".label")[0][i]).text);
                        //d3.select(d3.selectAll(".label")[0][i]).style("visibility", "visible");
                        return "visible";
                    }
                }
            });*/
            console.log(lHideNode)
            if (!lHideNode) {
              console.log("hide")
                // we need hide the text for this circle 
                //d3.select(d3.selectAll(".label")[0][i]).style("visibility", "hidden");
                return "hidden";
            }
            else
            {
              return "visible";
            }
        });

  console.log(filter_condition);
 console.log(aVisibility);
 var pathvisibility=(d3.selectAll(".path_placeholder").style("visibility"));
 console.log(filter_condition+","+pathvisibility);
d3.selectAll(".path_placeholder").style("visibility",function(o,i){
  console.log()
    return o === filter_condition ? aVisibility : d3.select(this).style("visibility");

 });
console.log(filter_condition+","+d3.selectAll(".path_placeholder").style("visibility")) 
    }

//var path line

function interpolateZoom (translate, scale) {
  console.log(translate+" "+scale)
    var self = this;
    return d3.transition().duration(350).tween("zoom", function () {
        var iTranslate = d3.interpolate(zoom.translate(), translate),
            iScale = d3.interpolate(zoom.scale(), scale);
        return function (t) {
            zoom
                .scale(iScale(t))
                .translate(iTranslate(t));
            zoomed();
        };
    });
}

function zoomClick(event) {
    console.log(event)
    console.log(event.target)

    var clicked = event.target,
        direction = 1,
        factor = 0.2,
        target_zoom = 1,
        center = [width / 2, height / 2],
        extent = zoom.scaleExtent(),
        translate = zoom.translate(),
        translate0 = [],
        l = [],
        view = {x: translate[0], y: translate[1], k: zoom.scale()};

    event.preventDefault();
    direction = (this.id === 'zoom_in') ? 1 : -1;
    target_zoom = zoom.scale() * (1 + factor * direction);
console.log("HERE")
  //  if (target_zoom < extent[0] || target_zoom > extent[1]) { return false; }
console.log("NOW HERE")
    translate0 = [(center[0] - view.x) / view.k, (center[1] - view.y) / view.k];
    view.k = target_zoom;
    l = [translate0[0] * view.k + view.x, translate0[1] * view.k + view.y];

    view.x += center[0] - l[0];
    view.y += center[1] - l[1];
    console.log("HEEEEEE")
    interpolateZoom([view.x, view.y], view.k);
}

d3.selectAll('#zoom_in').on('click', zoomClick);


function attrList(validList){

  var prev=document.getElementsByClassName("CB");
  console.log(prev.length)
 while(prev[0])
    {
      var id=prev[0].id;
      console.log(id);
      var label=document.getElementById("labelfor"+id);
      console.log(prev[0])
      prev[0].parentNode.removeChild(prev[0]);
      label.parentNode.removeChild(label);
      //prev[i].parentNode.removeChild(prev[i]);
      //console.log(label);
     
      //var label=document.getElementById(label);
      //label.parentNode.removeChild(label)
    }
    $('br', "#legend-1").remove();





   // prev.parentNode.removeChild(prev);
 var iterator1 = validList.values()
 if(!iterator1)
    return;
   
   for(var i=0;i<validList.size;i++)
   {
   // console.log(iterator1.next().value);
   var item=iterator1.next().value;
  /* var div_ele=document.createElement("div");
   div_ele.className="radiolist";*/
    var checkbox=document.createElement("input");
     checkbox.type="radio";
  checkbox.id="cb"+i;
  checkbox.className="CB";
  checkbox.value=item;
  checkbox.name="attr";
  document.getElementById('legend-1').appendChild(checkbox);
  var label=document.createElement('label');
  label.htmlFor=checkbox.id;
  label.id="labelfor"+checkbox.id;
  label.appendChild(document.createTextNode(item));
   
    document.getElementById('legend-1').appendChild(label);
    document.getElementById('legend-1').appendChild(document.createElement("br"));    
   }
 
 document.getElementById('legend-1').onclick=function(){
 

  //alert("checled");
   for(i=0;i<document.getElementsByClassName('CB').length;i++){
    if(document.getElementsByClassName("CB")[i].checked){
      filter_criterion=document.getElementsByClassName("CB")[i].value;
      console.log(filter_criterion);
      break;
    }
   }
   createlegend();
   console.log("AT attrList ")
   filter();
}
}


//INteractive when new node is created with the filtering on, the filtering change is reflected immediately
//What if the undefined node is later assigned a value?
//UNdefined legend click-->not hidden?

function dijkstraAlgo(){

  console.log("dijkstraAlgo")

    var dijkstra = d3.dijkstra()
    .nodes(graphData.nodes)
    .edges(graphData.links);


  var colour = d3.scale.linear()
    .domain([0, 1000, 2500])
    .range(["green", "yellow", "red"]);

  
 /* dijkstra.on("tick", function() {
     node.transition().style("fill","#FF8C00");
  });*/


  dijkstra.on("end", function() {
    var name = dijkstra.source().name;
    node.select("title")
        .text(function(d) { 
        	console.log(d.name+ "\n(" + d.distance + " miles from " + name + ")" );
        		return d.name + "\n(" + d.distance + " miles from " + name + ")" });
  });

node.on("click",dijkstra.start);
}

function multipleDropdown(validList){
	console.log(validList)
  if (document.getElementById("mySelect"))
   { alert("Loading Graph")
    $('#mySelect').html(''); 
    $("#mySelect").multiselect('destroy')
  }

	var selectList = document.createElement("select");
selectList.id = "mySelect";
selectList.setAttribute("multiple","multiple")
var target = document.getElementById('new');

console.log(validList.size)

	var data1=graphData.nodes;
	result=[];
	 map = new Map();

console.log(result)

var iterator1 = validList.values()
 if(!iterator1)
    return;
   
   for(var i=0;i<validList.size;i++)
   {
   // console.log(iterator1.next().value);
   var item=iterator1.next().value;
//Create and append the options
for (var entry of data1) {
    if(!map.has(entry[item])){
        map.set(entry[item], true);    // set any value to Map
        result.push({
            id: item,
            name: entry[item]
        });
    }
}
console.log(result)

  //  var option = document.createElement("option");
   // option.value = item;
    //option.text = item;

    //selectList.appendChild(option);
}
/*$('#mySelect').on('change', function (e) {
    on_selection_changed();
});
*/
var expensesByName = d3.nest()
  .key(function(d) { return d.id; })
    .rollup(function(v) { 
    	return {
    	value: v.name} })
     .entries(result);
console.log(JSON.stringify(expensesByName));


document.getElementsByClassName("container-fluid")[0].appendChild(selectList)


 
 propValList=[]
 console.log(result.keys)
 iterator1=validList.values()
  if(!iterator1)
    return;
   
   for(var i=0;i<validList.size;i++)
   {
   // console.log(iterator1.next().value);
   var item=iterator1.next().value;
 	var distinctitem=[...new Set(graphData.nodes.map(x=>x[item]))]
 	console.log(distinctitem)
 	propValList.push({
 		"key": item,
 		"values": distinctitem});
 }

console.log(propValList)


listgroups = d3.select('#mySelect').selectAll('optgroup')
  .data(propValList)

 listgroups.enter().append('optgroup')
  .attr("label",function(d){
  	console.log(d.key)
  	return d.key
  })

 listgroups.exit().remove()
  cibo = listgroups.selectAll('option')
  .data(function(d){
  	return d.values
  })

  console.log(cibo)
  
cibo.enter().append('option')
  .text(function(d){
  console.log(d)
  	return d})
  .attr("value",function(d){
  	return d
  })
   
   cibo.exit().remove()
        $('#mySelect').multiselect({
   buttonWidth: '300px',
    maxHeight: 400,
    enableCollapsibleOptGroups: true,
      collapseOptGroupsByDefault: true,  
    

      onChange: function(options, checked) {
                var $option = $(options);
                console.log(options)
                console.log($('#mySelect option:selected').length);
                console.log($option.length)
               // alert(options.length + ' options ' + (checked ? 'selected' : 'deselected'));
                if (checked)
                  console.log("selected")
                  //alert("selected")
                else
                 { //alert("deselected")
               link.attr("marker-end",function(d){
                return "url(#end)"

               })


        node.style("opacity", function (o,i) {
           
            //return o[filter_criterion] === filter_condition ? aVisibility : lOriginalVisibility;
            return "1"

            
        });


    link.style("stroke-opacity", function(d) {
               
          return "1"
      

            });




             }
                if($('#mySelect option:selected').length >2)
                	{alert("Cannot select more than 2 groups to filter by")
                 $("#mySelect").multiselect('deselect', $option.val());

            }
            else{
                if ($option.length == 1) {
 
                    var $group = $option.parent('optgroup')
                    console.log($group)
                    if($group.find(":selected").length >1)
                     console.log($group.find(":selected").length)
                    if ($group.find(":selected").length >1) {
                        var $options = $('option', $group);
                        $options = $options.filter(':selected');
 
                        if (checked && $options.length > 1) {
                            alert('Cannot select more than 1 elements in this group!');
                            $("#mySelect").multiselect('deselect', $option.val());
                        }
                    }
                }
            }
            if($('#mySelect option:selected').length==2)
            	filtermutilple($('#mySelect option:selected').val);
           
  }
  });


    
}
//document.getElementById("mySelect").addEventListener("change", printMsg);

function wasDeselected (sel, val) {
  if (!val) {
    return true;      
  }
  return sel && sel.some(function(d) { return val.indexOf(d) == -1; })
}

function printMsg(e){
	//=console.log("HHEEH")
	var e = document.getElementById ("mySelect");
var strUser = e.options [e.selectedIndex] .value
	console.log(strUser)



}

 function on_selection_changed() {
 	console.log("HEHEHEH")
    var i, len, ref, so, so_values;
    so_values = [];
    ref = d3.select('#mySelect').node().selectedOptions;
    for (i = 0, len = ref.length; i < len; i++) {
      so = ref[i];
      so_values.push(so.value);
    }
    return console.log(so_values);
  };


function filtermutilple(val){

	//alert("FILREE")
	  var select1 = document.getElementById("mySelect");
    var selected1 = {};
    var multipleprop=[]
    for (var i = 0; i < select1.length; i++) {
        if (select1.options[i].selected) 
        	{
        		obj={}
        		multipleprop.push(select1.options[i].parentNode.label)
        		selected1[select1.options[i].parentNode.label]= select1.options[i].value;
        		//selected1.push(obj)
        		//console.log(select1.options[i].parentNode.label)
        	}

    }
    //console.log(selected1[0].key);
    console.log(multipleprop)
    console.log(selected1[multipleprop[0]])
   for(var item in selected1){
      for(subitem in selected1[item])
      
        console.log(selected1[item][subitem]);
    }
    //nod
    console.log(selected1)
    Object.keys(selected1).forEach(function(key){
    var value = selected1 [key];
    console.log()
    console.log(key + ':' + value);
});

     node.style("opacity", function (o,i) {
            var lOriginalVisibility = $(this).css("visibility");
         
            //d3.select(d3.selectAll(".label")[0][i]).style("visibility",o[filter_criterion] === filter_condition ? aVisibility : lOriginalVisibility)
              if(o[multipleprop[0]]==selected1[multipleprop[0]])
              	console.log(o[multipleprop[0]]+"-"+selected1[multipleprop[0]])
              if(o[multipleprop[1]]==selected1[multipleprop[1]])
              	console.log(o[multipleprop[1]]+"-"+selected1[multipleprop[1]])
            if(o[multipleprop[0]]==selected1[multipleprop[0]] & o[multipleprop[1]]==selected1[multipleprop[1]])
            	{console.log(o)
            	return "1";
            	}
            //return o[filter_criterion] === filter_condition ? aVisibility : lOriginalVisibility;
            return "0.1"

            
        });


    link.style("stroke-opacity", function(d) {
      	       sourcelinkop=""
      	       targetlinkop=""
             node.filter(function(o,i){
               	if (d.target===o )
               		{console.log(o)

               		console.log($(this).css("opacity"))
               		 targetlinkop= $(this).css("opacity")
               	}
               	if(d.source===o)
               	{
               		console.log($(this).css("opacity"))
               		sourcelinkop= $(this).css("opacity")
               	}
               })
             console.log(targetlinkop)
             console.log(sourcelinkop)
    	   if (targetlinkop==1 && sourcelinkop==1)
    	   	return "1"
    	   else
    	   	return "0.1"

            });
    link.attr("marker-end",function(d){
    	sourcelinkop=""
    	targetlinkop=""
    	console.log(d)
    	 node.filter(function(o,i){
               	if (d.target===o )
               		{console.log(o)

               		console.log($(this).css("opacity"))
               		 targetlinkop= $(this).css("opacity")
               	}
               	if(d.source===o)
               	{
               		console.log($(this).css("opacity"))
               		sourcelinkop= $(this).css("opacity")
               	}
               })
    	 console.log(targetlinkop)
    	 console.log(sourcelinkop)
    	   if (targetlinkop==1 && sourcelinkop==1)
    	   {
    	   	console.log("1")
    	   	return "url(#end)"}
    	   else
    	   	{
    	   		console.log("0.1")
    	   		return "url(#end-arrow-fade)"}

    })
         
          



}

function SearchAutofill(){
  var optArray = [];
for (var i = 0; i < graphData.nodes.length - 1; i++) {
    optArray.push(graphData.nodes[i].name);
}

optArray = optArray.sort();

  var options = '';

  for(var i = 0; i < optArray.length; i++)
    options += '<option value="'+optArray[i]+'" />';


    document.getElementById('searchlist').innerHTML = options;


}

function resettable(){
    var elem = document.getElementById('table_node');

if (elem != null)
{
  elem.parentNode.removeChild(elem);
}
var elem2=document.getElementById("table_link")
if(elem!=null)
{
  elem2.parentNode.removeChild(elem2)
}

}
function searchNode(){
  var elem = document.getElementById('table_node');

if (elem != null)
{
  elem.parentNode.removeChild(elem);
}

var elem2=document.getElementById("table_link")
if(elem!=null)
{
  elem2.parentNode.removeChild(elem2)
}
  var selectedVal=document.getElementById('search').value

   var selectednode = node.filter(function (d, i) {
            return d.name != selectedVal;
        });
   var selectedlabel= label.filter(function(d,i){
    return d.name!=selectedVal
   })
        selectednode.style("opacity", "0");
        selectedlabel.style("opacity","0")
        var link = svg.selectAll(".link")
        var selectededgeweights=svg.selectAll(".edgeweight")
        selectededgeweights.style("opacity","0")
        var groups=svg.selectAll(".groups")
        groups.style("opacity","0")
        link.style("opacity", "0");
        d3.selectAll(".node, .link ,.label , .edgeweight, .groups").transition()
            .duration(5000)
            .style("opacity", 1);

        var node_details=graphData.nodes.filter(function(d){
          if (d.name==selectedVal)
            return d
        })
    console.log(node_details)
        var prop=new Set(["index","weight","x","y","px","py","selected","possible","fixed"]);
    var validList = d3.keys(node_details).filter((item) => {
  return !prop.has(item);
})

     var tbl = document.createElement('table');
  tbl.setAttribute('border', '1');
  tbl.setAttribute('id','table_node')
  var tbdy = document.createElement('tbody');
   for (var key in node_details[0]) {
    //console.log(key)
    //console.log(prop.has(key))
   if (!prop.has(key)) {
     var tr = document.createElement('tr');
         var td = document.createElement('td');
         var cell1=tr.insertCell(0)
         
         var cell2=tr.insertCell(1)
         cell1.innerHTML=key
         cell2.innerHTML=node_details[0][key]
         cell2.setAttribute("id",key)
         if(key!="id")
          cell2.setAttribute("contenteditable",true)
      console.log(node_details[0][key]);
      tbl.append(tr)
   }
   var connectedlinks=[]
   graphData.links.filter(function(d){
    console.log(d.source.id)
    console.log(node_details[0].id)
    if(d.source.id==node_details[0].id)
      {connectedlinks.push({"source":node_details[0].name,"target":d.target.name,"edgeweight":d.edgeweight})
        console.log("HEE")
      }
    else if(d.target.id==node_details[0].id)
      connectedlinks.push({"source":d.source.name,"target":node_details[0].name,"edgeweight":d.edgeweight})
   })
   console.log(connectedlinks)


}
$("#tab-4").append(tbl)
$("#tab-4").append("<br>")
var tbl2=document.createElement("table")
tbl2.setAttribute("id","table_link")
tbl2.setAttribute('border', '1');
for(var i=0;i<connectedlinks.length;i++)
{
    var tr = document.createElement('tr');
    var cell1=tr.insertCell(0)
         
    var cell2=tr.insertCell(1)
    var cell3=tr.insertCell(2)
    cell1.innerHTML="link"
    cell2.innerHTML=String(connectedlinks[i].source)+"-"+String(connectedlinks[i].target)
    cell3.innerHTML=connectedlinks[i].edgeweight
    cell3.setAttribute("id",String(connectedlinks[i].source)+"-"+String(connectedlinks[i].target))
    cell3.setAttribute("contenteditable",true)
tbl2.append(tr)

}
$("#tab-4").append(tbl2)
var oldnodeval;
$('#table_node').on('focusin', function(){
    console.log("Saving value " + document.getElementById("name").innerHTML);
    oldnodeval=document.getElementById("name").innerHTML
    console.log(oldnodeval)
    
});
document.getElementById("table_node").addEventListener("input",function(e) {
   if(e.target.id=="id")
    return
//alert(e.target.id)
//alert(e.target.innerHTML)
 graphData.nodes.filter(function(k){
     
          if (k.id==node_details[0].id)
           { 
            console.log(k.id)
           //console.log(node.id)

            k[e.target.id]=e.target.innerHTML
            update()
            console.log(document.getElementById("table_link"))
            console.log(e.target.innerHTML)
 $('#table_link tr').each(function(){
    $(this).find('td').each(function(){
        //do your stuff, you can use $(this) to get current cell
        console.log(this.id)
        console.log(oldnodeval)
        console.log(this.textContent)
        if(this.textContent.includes("-"))
        {
          var text=this.textContent.split("-")
          if(text[0]==oldnodeval)
           {console.log(text[0])
            text[0]=e.target.innerHTML


           }
          else if(text[1]==oldnodeval)
           { console.log(text[1])
            text[1]=e.target.innerHTML

           }
           this.textContent=text[0]+"-"+text[1]
          //.setAttribute("id",text[0]+"-"+text[1])
           //$("#table_link tr td:nth-child(2)").attr("id",text[0]+"-"+text[1])
        }
        if(this.id.includes("-")){
          var text=this.id.split("-")
           if(text[0]==oldnodeval)
           {console.log(text[0])
            text[0]=e.target.innerHTML
            


           }
          else if(text[1]==oldnodeval)
           { console.log(text[1])
            text[1]=e.target.innerHTML
          

           }
           this.id=text[0]+"-"+text[1]
        }
    })
})

            return
           }
           /*if (k.id==node.id)
            alert("Hbehn")*/

        })

});

document.getElementById("table_link").addEventListener("input",function(e){
  var link_split=(e.target.id.split("-"))
  console.log(link_split)
  graphData.links.filter(function(k){
    console.log(k)
    if(k.source.name==link_split[0] && k.target.name==link_split[1])
    {
      k["edgeweight"]=e.target.innerHTML
      update()
      return
    }
  })
})
    }

  

  function bfs(startnode){
     var queue=[];
  var animX=0;
  //console.log(graphData.nodes[0].name)
  queue.push(startnode);
 while(queue.length!==0){
    var element = queue.shift();
    console.log(element)
    console.log(element)
    visitElement(element,animX);
    animX= animX+1;
    children=[]
   graphData.links.filter(function(d){
      console.log("hehe")
      console.log(d.source.name)
      if (d.source.id===element)
        {
          console.log(d.target.id)
          children.push(d.target.id)

        }
    })
    console.log(children)
    if(children!==undefined){
      for(var i=0; i<children.length; i++){
        queue.push(children[i]);
      }


    }
  }
}

function bfs_undirected(startnode){
  var queue=[];
  var animX=0;
  //alert("undirected")
  var visited=new Set()
    //console.log(graphData.nodes[0].name)
  queue.push(startnode);
 while(queue.length!==0){
  
    var element = queue.shift();
    console.log(element)
    console.log(element)

    visitElement(element,animX);
    visited.add(element)
    animX= animX+1;
    children=[]
   graphData.links.filter(function(d){
      console.log("hehe")
      console.log(d.source.name)
      if (d.source.id===element)
        {
          console.log(d.target.id)
          if (visited.has(d.target.id)==false)
           children.push(d.target.id)

        }
      else if (d.target.id===element)
      {
        console.log(d.source.id)
        if (visited.has(d.source.id)==false)
           children.push(d.source.id)
        //children.push(d.source.id)
      }
    })
    console.log(children)
    if(children!==undefined){
      for(var i=0; i<children.length; i++){
        queue.push(children[i]);
      }


    }
  }

}
  function visitElement(element,animX){
 // d3.select("#node-"+element.id).classed("visited",true);
  d3.select("#node"+element)
    .transition().duration(5000).delay(7500*animX)
    .style("fill","green").style("stroke","red");
}

function dfs(startnode){
  var stack=[];
  var animX=0;
  stack.push(startnode);
  console.log(startnode)
  while(stack.length!==0){
    var element = stack.pop();
    visitElement(element,animX);
    animX=animX+1;
     children=[]
   graphData.links.filter(function(d){
      console.log("hehe")
      console.log(d.source.name)
      if (d.source.id===element)
        {
          console.log(d.target.id)
          children.push(d.target.id)

        }
    })
   if(children!==undefined){
      for(var i=0; i<children.length; i++){
        stack.push(children[children.length-i-1]);
      }
    }
    
  }
}

function dfs_undirected(startnode){
 var stack=[];
  var animX=0;
  var visited=new Set()
  stack.push(startnode);
  console.log(startnode)
  while(stack.length!==0){
    var element = stack.pop();
    visitElement(element,animX);
    visited.add(element)
    animX=animX+1;
     children=[]
   graphData.links.filter(function(d){
      console.log("hehe")
      console.log(d.source.name)
      if (d.source.id===element)
        {
          console.log(d.target.id)
          if (visited.has(d.target.id)==false)
            children.push(d.target.id)

        }
      else if (d.target.id===element)
        {
          if (visited.has(d.source.id)==false)
            children.push(d.source.id)

        }
    })
   if(children!==undefined){
      for(var i=0; i<children.length; i++){
        stack.push(children[children.length-i-1]);
      }
    }
    
  }

}


function primsMST(startnode){
var graph = graphData.links.map(function(e) {
  
    return [e.source.id, e.target.id,e.edgeweight];
})
//graph is a list of lists [ [source,link,edgeweight], [source,link,edegeweight]....]
 

console.log(graph)
 var vertex = 0;
  
  // initialize empty edges array and empty MST
  var MST = [];
  var edges = [];
  var visited = [];
  var minEdge = [null,null,Infinity];
  var vertex=startnode
  console.log(startnode)
  console.log(edges)
 
  // run prims algorithm until we create an MST
  // that contains every vertex from the graph
 while (MST.length !== graphData.nodes.length-1) {
    
    // mark this vertex as visited
    console.log("Vertex "+vertex+" visted")
    visited.push(vertex);
      
    
    // add each edge to list of potential edges
    for (var r = 0; r < graph.length; r++) {

       if (graph[r][0]==vertex && graph[r][2] !== 0 || graph[r][1]==vertex && graph[r][2]!==0) { 
        console.log(graph[r])
        edges.push(graph[r]); 
         console.log("adding edges "+graph[r])
      }
      
    }


    

    for (var edge in edges)
      console.log(edges[edge])
    console.log(edges.length)

    for (var j=0;j<visited.length;j++)
      console.log(visited[j])
    
    // find edge with the smallest weight to a vertex
    // that has not yet been visited
    for (var e = 0; e < edges.length; e++) {
      //console.log((edges[e][0][2])<minEdge[2])
      //console.log(visited.indexOf(edges[e][0][1]) === -1)
      console.log(edges[e])
      console.log("min is"+minEdge[2]+"current is"+edges[e][2])
     
        if (edges[e][2] < minEdge[2] && visited.indexOf(edges[e][1]) === -1) { 
          console.log(edges[e][0][2])
          minEdge = edges[e]; 
      }
    
     
          if (edges[e][2]< minEdge[2] && visited.indexOf(edges[e][0])=== -1)
        {
          console.log(edges[e][0][2])
          minEdge=edges[e]
        }

    }
    console.log("Smallest edge"+minEdge)
    
    // remove min weight edge from list of edges
    console.log(minEdge[0])
    for (var e = 0; e < edges.length; e++)
     { 
      console.log(edges[e])
      if (edges[e][0]==minEdge[0] && edges[e][1]==minEdge[1])
        console.log(edges[e])

      }
    console.log(edges.length)
    console.log(edges.indexOf(minEdge))
    edges.splice(edges.indexOf(minEdge), 1);
    console.log(edges.length)
   /* var filteredAry = edges.filter(function(e) { 
      if (e[0]!=minEdge[0] && e[1]!= minEdge[1] )
        console.log(e)
      return e[0]!=minEdge[0] && e[1]!= minEdge[1] 
    })
    */

    console.log(edges.length)
    
    // push min edge to MST
    linkid=""
    graphData.links.filter(function(d){
      if (d.source.id==minEdge[0] && d.target.id==minEdge[1])
       linkid="link"+d.source.name+d.target.name
     else if (d.target.id==minEdge[1] && d.target.id==minEdge[0])
      linkid="link"+d.source.id+d.target.name
    })
    console.log(linkid)
  /* link.style("stroke",function(d){
    if (d.source.id==minEdge[0] && d.target.id==minEdge[1])
      return "green"
   })*/

    //d3.select("#"+linkid).transition().delay(5000/8).duration(7500*edges.length).style("stroke","blue")

    //d3.select('#node'+vertex).transition().delay(5000/8).duration(7500*vertex.length).style("stroke","purple")
    console.log(vertex)

   d3.select("#"+linkid).transition().duration(20).delay(2000* MST.length).style("stroke","red").attr("stroke-width",10).attr('stroke-opacity', 1);
   // d3.select("#node"+vertex).transition().duration(2000*MST.length).style("fill","green")


    MST.push(minEdge);
    console.log(MST)
      
    // start at new vertex and reset min edge
    if (minEdge)
     {
      if (vertex==minEdge[0])
        vertex = minEdge[1];
      else 
        vertex=minEdge[0]
      console.log(vertex)
      minEdge = [null,null,Infinity];}
    
  }
    //d3.select("#node"+vertex).transition().duration(2000*MST.length).style("fill","green")

  console.log(MST)


}

 

 $( function() {
    $( "#tabs" ).tabs();
  } );

    // Assuming that input is in `input`


function createtree (object) {
        var o = {}, children = {};

        object.nodes.forEach(function (a, i) {
            o[i] = { name: a.name };
        });
        console.log(o)

        object.links.forEach(function (a) {
            o[a.target].parent = o[a.source].name;
            o[a.source].children = o[a.source].children || [];
            o[a.source].children.push(o[a.target]);
            children[a.target] = true;
        });

        return Object.keys(o).filter(function (k) {
            return !children[k];
        }).map(function (k) {
            return o[k];
        });
    };


 function inorder(){
  inOrderHelper(graphData.nodes[0].id);

 }

 function inOrderHelper(root) {
  if (root==null)
   { 
    //console.log("HEREE")
    return

   }
  else {
    var children=[]
    //console.log(root)
    graphData.links.filter(function(d){
      //console.log(d)
      if (d.source.id==root)
       { 
        children.push(d.target.id)
       }
    })
   // console.log(children)
      inOrderHelper(children[0]);
     // console.log(children[0])
       d3.select("#node"+root).transition().duration(300).delay(750*root)
    
    .style("fill","green").style("stroke","red")
      console.log(root);
      inOrderHelper(children[1]);
   }
}
var nestedarray;
 function preorder(){
  //creategraph()
  nestedarray={}
  nestedarray=d3.nest()
  .key(function(d) { return d.source.id; })
  .entries(graphData.links);
  console.log(nestedarray)
  var filtered = nestedarray.filter(function(d,i) {
    console.log(d.key)
    if(d.key == graphData.nodes[0].id)
      return i
});
  console.log(nestedarray[i].values)
  console.log(nestedarray[graphData.nodes[0].id])
  console.log(nestedarray[graphData.nodes[1].id])
  preorderhelper(graphData.nodes[0].id);

 }

 function preorderhelper(root) {
  index=-1
    nestedarray.filter(function(d,i) {
    if(d.key == root)
       index=i
});
      d3.select("#node"+root).transition().duration(300).delay(750*root)
    
    .style("fill","green").style("stroke","red")
  if (index==-1)
   { 
    //console.log("HEREE")
    return

   }
  else {
    var children=[]
    console.log(root)
    var index
  
    console.log(index)
    console.log(nestedarray[index])
  //console.log(nestedarray[filtered].values)
  var left,right;
  
left=nestedarray[index].values[1].target.id
right=nestedarray[index].values[0].target.id
console.log(left)
console.log(right)
 
    //console.log(root)
  
   // console.log(children)
      preorderhelper(left);
     // console.log(children[0])
       
      preorderhelper(right);
   }
}



function nodeById(id) {
  console.log(id)
  // return the node if it's been found before, otherwise loop over the
  // array to find it
  if(cachedNodesById[id] != null) { return cachedNodesById[id]; }
  else {
    for(var i=0; i < nodes.length; i++) {
      if(nodes[i].Id == id) { return cachedNodesById[id] = nodes[i]; }
    }
  }
}


function changeRadius(){
  var radiusSliderval=document.getElementById("radiusSlider").value
  d3.selectAll("circle").transition().duration(120).attr("r",radiusSliderval)
}

function changeLinkdistance(){
  var linkdistval=document.getElementById("linkDistanceSlider").value
  console.log(linkdistval)
  force.linkDistance(linkdistval)
  force.start()
}

function changeCharge(){
  var chargeval=document.getElementById("chargeSlider").value
  console.log(chargeval)
  force.charge(chargeval)
  force.start()
}

function changeLinkstrength(){
  var linkstrengthval=document.getElementById("linkStrengthSlider").value

  force.linkStrength(linkstrengthval)
  force.start
}

function createMatrix(){
   var matrix = []
      var nodes = graphData.nodes
    var  n = nodes.length;
  /*nodes.forEach(function(node, i) {
    node.index = i;
    node.count = 0;
    matrix[i] = d3.range(n).map(function(j) { return {x: j, y: i, z: 0}; });
  });
  console.log(nodes)
  // Convert links to matrix; count character occurrences.
  graphData.links.forEach(function(link) {
    console.log(link)
    matrix[link.source.id][link.target.id].z += link.edgeweight;
    matrix[link.target.id][link.source.id].z += link.edgeweight;
    //matrix[link.source][link.source].z += link.value;
    //matrix[link.target][link.target].z += link.value;
    nodes[link.source].count += link.value;
    nodes[link.target].count += link.value;
  });*/


  for(i=0;i<graphData.nodes.length;i++)
  {
    var curr=graphData.nodes[i]
    console.log(curr)
    var arr=new Array(graphData.nodes.length).fill(0);
    graphData.links.forEach(function(d,j){
      console.log(i)
      if(d.source.id==curr.id)
        {
          
          arr[d.target.index]=parseInt(d.edgeweight)


        }
     
    })

    matrix.push(arr)



  console.log(matrix)
 // var isbi=isbipartite(1)
  //console.log(isbi)
}
return matrix
}

function twocolor(){
  createMatrix()
   var isbi=isbipartite(1)
   console.log(isbi)
}
function isbipartite(src){
  var colorArr =new Map();
  for(i=0;i<graphData.nodes.length;i++){
    if(graphData.nodes[i].id==src)
    colorArr.set(graphData.nodes[i].id,1)
  else
    colorArr.set(graphData.nodes[i].id,-1)
  }
  console.log(colorArr)
  queue = [] 
  var flag=false
  var visited=new Set()
  queue.push(src) 
   while(queue.length!==0){
    var element = queue.shift();
    console.log(element)
    //console.log(element)
    //visitElement(element,animX);
    //animX= animX+1;
    visited.add(element)
    children=[]
   /* for(i=0;i<graphData.links.length;i++){

      if(graphData.links[i].source.id==element && colorArr.get(graphData.links[i].target.id)==-1)
      {
         if (visited.has(graphData.links[i].target.id)==false)
        { 
          console.log("HEHE")
          //console.log(colorArr[d.target.id])
          colorArr.set(graphData.links[i].target.id,1-colorArr.get(element))
          //colorArr[d.target.id]=1 - colorArr[element]
          console.log(colorArr)
           queue.push(graphData.links[i].target.id)
        }
      }
      else if(graphData.links[i].target.id==element && colorArr.get(graphData.links[i].source.id)==-1){
        if (visited.has(graphData.links[i].source.id)==false)
        { 

          console.log("HEHE")
          // console.log(colorArr[d.source.id])
         // colorArr[d.source.id]=1 - colorArr[element]
         colorArr.set(graphData.links[i].source.id,1-colorArr.get(element))
          console.log(colorArr)
           queue.push(graphData.links[i].source.id)
        }
      }
       else if((graphData.links[i].source.id===element && colorArr.get(graphData.links[i].target.id)==colorArr.get(element))){
    return false
   }
    
   else if((graphData.links[i].target.id===element && colorArr.get(graphData.links[i].source.id)==colorArr.get(element))){
   
    return false
   }    }*/
   var x=graphData.links.filter(function(d){
      console.log("hehe")
      console.log("LINK"+d.source.id+"-"+d.target.id)
      if(flag==true)
      console.log(colorArr.get(d.target.id))
      console.log(colorArr.get(d.source.id))
     console.log (d.source.id===element && colorArr.get(d.target.id)==colorArr.get(element))
     console.log( (d.target.id===element && colorArr.get(d.source.id)==colorArr.get(element)))
      if (d.source.id===element && colorArr.get(d.target.id)==-1)
        {
          //console.log(d.source.id+"-"+d.target.id)
          //children.push(d.target.id)
          if (visited.has(d.target.id)==false)
        { 
          console.log("HEHE")
          console.log(colorArr[d.target.id])
          colorArr.set(d.target.id,1-colorArr.get(element))
          //colorArr[d.target.id]=1 - colorArr[element]
           //d3.select("#node"+d.target.id).style("fill",color(colorArr.get(d.target.id)))
          console.log(colorArr)
           queue.push(d.target.id)
        }

        }
        else if (d.target.id===element && colorArr.get(d.source.id)==-1)
      {
        //onsole.log(d.source.id)
        console.log(d.source.id+"-"+d.target.id)
        if (visited.has(d.source.id)==false)
        { 

          console.log("HEHE")
           console.log(colorArr[d.source.id])
         // colorArr[d.source.id]=1 - colorArr[element]
         colorArr.set(d.source.id,1-colorArr.get(element))
         //d3.select("#node"+d.source.id).style("fill",color(colorArr.get(d.source.id)))
          console.log(colorArr)
           queue.push(d.source.id)
        }
        //children.push(d.source.id)
      }
         else if( (d.source.id===element && colorArr.get(d.target.id)==colorArr.get(element))){
          flag=true
    return false
   }
    
   else if((d.target.id===element && colorArr.get(d.source.id)==colorArr.get(element))){
    console.log("FAKSEE")
    flag=true
    return false
   }
  })
  if(flag==true)
  {
    alert("Graph is not bipartite. 2 Colouring is not possible")
    return false
  
  }
    /*console.log(children)
    if(children!==undefined){
      for(var i=0; i<children.length; i++){
        queue.push(children[i]);
      }*/


    }
console.log(colorArr)
colournodesbipartite(colorArr)
return true

  }
  
function colournodesbipartite(colorArr){
  console.log(colorArr)
  for(i=0;i<graphData.nodes.length;i++){
    console.log('eheji')
    if(colorArr.has(graphData.nodes[i].id))
      console.log(d3.select("#node"+graphData.nodes[i].id).style("fill",color(colorArr.get(graphData.nodes[i].id))))
  }
}


       
function solveFlow (source,sink){

  var matrix=createMatrix()

flow=fordFulkerson(matrix, source, sink)

  $("#algotext").empty()
var textnode=document.createTextNode("Maximum Flow is"+ flow)
document.getElementById("algotext").appendChild(textnode)
      var textnode=document.createTextNode(text)
      document.getElementById("algotext").appendChild(textnode)



  }



function bfs_ford(rGraph, s, t, parent) {
  console.log("augmenting path")
  var visited = [];
  var queue = [];
  var V = rGraph.length;
  // Create a visited array and mark all vertices as not visited
  for (var i = 0; i < V; i++) {
    visited[i] = false;
  }
  // Create a queue, enqueue source vertex and mark source vertex as visited
  queue.push(s);
  visited[s] = true;
  parent[s] = -1;
  console.log(s)
  while (queue.length != 0) {
    var u = queue.shift();
    console.log(u)
      for (var v = 0; v < V; v++) {
      if (visited[v] == false && rGraph[u][v] > 0) {
        console.log(v)
        queue.push(v);
        parent[v] = u;
        visited[v] = true;
      }
    }
  }
  //If we reached sink in BFS starting from source, then return true, else false
  console.log(parent)
  return (visited[t] == true);
}

function maxflow(){

}

function initializeflow(){
  console.log(d3.selectAll(".edgeweight").length)
  d3.select(".edgeweight").selectAll("*")
  var children=d3.select(".edgeweight").ChildNodes
  console.log(children)
    edgeweight
            .text(function (d){ if(d.edgeweight) return d.edgeweight+"/"+0;})
}

function setDelay(i) {
  setTimeout(function(){
    console.log(i);
  }, 5000);
}

function transition(linkarray,i) {
  console.log(linkarray)
    setTimeout(function () {
        var now=d3.select('#link'+linkarray[i]);
        now.transition().duration(100).style("stroke","green").on("end",function(){

        });
        i--;
        if (i >0) {
            transition(linkarray,i);
        }
    }, 200) // change this time (in milliseconds) to whatever you desire

}
function mytransition(linkarray,index) {
  //console.log(d3.selectAll(".link"))
   //link.style("stroke-width",1.5)
  
 
var text=""
    //d3.selectAll(".link").style("stroke","green")
  console.log("meyx")
  translate_speed=5000
  for(var j=linkarray.length;j>=0;j--){
    console.log(linkarray[j])
    var source=graphData.nodes.find(function(d){
      if(typeof linkarray[j]!=="undefined")
      return d.id==linkarray[j][0]
    })
    var target=graphData.nodes.find(function(d){
      if(typeof linkarray[j]!=="undefined")
      return d.id==linkarray[j][1]
    })
    console.log(source)
    console.log(target)
    if(j==linkarray.length-1)
    {
      if(typeof source!=="undefined" && typeof target!=="undefined")
       { text=text + source.name+"->"+target.name
      //var textnode=document.createTextNode(source.name+"->"+target.name)
    }
    }
    else
    {
      if(typeof target!=="undefined")
      {
         text=text +"->"+target.name
        // var textnode=document.createTextNode("->"+target.name)
  }
    }
    
  
    d3.select("#link"+linkarray[j]).transition().delay((translate_speed*index)+j).duration(7500).style("stroke", "red").style("stroke-width",3).each("start",function(){
      $("#algotext").empty()
var textnode=document.createTextNode("Augmenting Path ")
document.getElementById("algotext").appendChild(textnode)
      var textnode=document.createTextNode(text)
      document.getElementById("algotext").appendChild(textnode)
    }).each("end",function(){
      d3.select(this).style("stroke","black").style("stroke-width",1.5)
      

    })
  }

    console.log("EMPTYING")


}

function augmentpath(nodeorder){

  console.log(nodeorder)
  for(var i=0;i<nodeorder.length;i++)
  {  mytransition(nodeorder[i],i)
  
  }
}

function fordFulkerson(graph, s, t) {
  /* Create a residual graph and fill the residual graph
   with given capacities in the original graph as
   residual capacities in residual graph
   Residual graph where rGraph[i][j] indicates
   residual capacity of edge from i to j (if there
   is an edge. If rGraph[i][j] is 0, then there is
   not)
  */
  var augement=[]
  var order=[]
  var linkcolor=[]
  for(var j=0;j<graph.length;j++)
    linkcolor[j]="red"
  console.log(s)
  console.log(t)
  console.log(graph.length-1)
  if (s < 0 || t < 0 || s > graph.length-1 || t > graph.length-1){
    throw new Error("Ford-Fulkerson-Maximum-Flow :: invalid sink or source");
  }
  if(graph.length === 0){
    throw new Error("Ford-Fulkerson-Maximum-Flow :: invalid graph");
  }
  var rGraph = [];
  for (var u = 0; u < graph.length; u++) {
    var temp = [];
    if(graph[u].length !== graph.length){
      throw new Error("Ford-Fulkerson-Maximum-Flow :: invalid graph. graph needs to be NxN");
    }
    for (v = 0; v < graph.length; v++) {
      temp.push(graph[u][v]);
    }
    rGraph.push(temp);
  }
  console.log(rGraph)
  var parent = [];
  var maxFlow = 0;
  initializeflow()
  while (bfs_ford(rGraph, s, t, parent)) {
    var nodeorder=[]
    var pathFlow = Number.MAX_VALUE;
    for (var v = t; v != s; v = parent[v]) {
      console.log(v)
      graphData.nodes.find(function(d){
        if (d.index==v)
          {console.log(d.id)
            //nodeorder.push(d.id)
}
      })

      if(d3.select("#link"+u+v)!=null){
        console.log(d3.select("#link"+u+v))
        console.log(u+"-"+v)

      }
      else if(d3.select("#link"+v+u)!=null)
        console.log(v+"-"+u)
      linkcolor[u]="green"
     // nodeorder.push(v)
      u = parent[v];
      var u_id=(graphData.nodes.find(function(d){if(d.index==u) return d}))
      var v_id=(graphData.nodes.find(function(d){if(d.index==v) return d}))
      if(d3.select("#link"+u_id["id"]+v_id["id"]).empty()==false){
        nodeorder.push(String(u_id["id"])+String(v_id["id"]))
        //d3.select("#link"+String(u_id["id"])+String(v_id["id"])).stroke("fill","green")
      }
      else if(d3.select("#link"+v_id["id"]+u_id["id"]).empty()==false){
        nodeorder.push(String(v_id["id"])+String(u_id["id"]))
        // d3.select("#link"+String(v_id["id"])+String(u_id["id"])).stroke("fill","green")
      }
      //d3.select("#link"+nodeorder.pop()).transition().duration(5000).style("stroke","green")
      //console.log(u) 
      //console.log(v)
      pathFlow = Math.min(pathFlow, rGraph[u][v]);
      console.log(u+"-"+v+":"+pathFlow)
      //nodeorder.push(v)
      console.log(d3.select("#link"+nodeorder[0]))
      console.log(linkcolor)
      animX=0
     /* nodeorder.forEach(function(link){
        console.log(link)
        d3.select('#link'+link).transition().delay(7500*animX).duration(7500).style("stroke","green")
        animX=animX+1

      })*/
     /*.filter(function(d,i){
        return d.id=="#link"+nodeorder.pop()
      }))*/
    
    }
    //transition(nodeorder,nodeorder.length-1)
    for (v = t; v != s; v = parent[v]) {
      u = parent[v];

      console.log(s+"-"+u+"-"+v)
      /*var s_id=graphData.nodes.find(function(d){
        if (d.index==u)
          nodeorder.push(d.id)
      })*/
      //console.log(s_id)
      
      edgeweight
         .filter(function (d, i) { return i === u;})
         .transition().duration(5000).delay(7500)
         // put all your operations on the second element, e.g.
         .text(function (d){ if(d.edgeweight) return d.edgeweight+"/"+rGraph[u][v];});

      rGraph[u][v] -= pathFlow;
      rGraph[v][u] += pathFlow;
    }
    console.log(nodeorder)
    console.log(node)
    //augmentpath(nodeorder,nodeorder.length-1,1)

    maxFlow += pathFlow;
    order.push(nodeorder)
  }
  // Return the overall flow
  console.log(order)
  augmentpath(order)
  alert("Maximum Flow between Source:"+s+" and Sink:"+t +" is "+ maxFlow)
  return maxFlow;
}


function topologicalsort(){
  console.log("GRAPHHHH")
  let graph_1=new Graph();
  for(var i=0;i<graphData.nodes.length;i++)
    graph_1.addNode(graphData.nodes[i].id)
  for(var j=0;j<graphData.links.length;j++)
    graph_1.addDirectedEdge(graphData.links[j].source.id,graphData.links[j].target.id)
console.log(graph_1)
/*let g = new Graph();
g.addNode(1);
g.addNode(2);
g.addNode(3);
g.addNode(4);
g.addNode(5);
g.addNode(6);
g.addNode(7);

g.addDirectedEdge(1, 3);
g.addDirectedEdge(1, 2);
g.addDirectedEdge(1, 4);
g.addDirectedEdge(3, 4);
g.addDirectedEdge(4, 5);
g.addDirectedEdge(5, 6);
g.addDirectedEdge(2, 7);
console.log(g)
g.topologicalSort();*/

sortedg=graph_1.topologicalSort()
$("#algotext").empty()
var textnode=document.createTextNode("The topological sorting is ")
document.getElementById("algotext").appendChild(textnode)
animX=0
for(var j=sortedg.length;j>=0;j--){

  let found=(graphData.nodes.find(el => el.id === sortedg[j]));
 // console.log(found)
  //d3.select("#node"+found.id).style("fill","purple")
  if(found)
   { console.log(found["name"])
 console.log(found)
 animX=animX+1
 d3.select("#node"+found["id"]).transition().duration(5000).delay(7500*animX).style("fill","orange").each("end",function(){
  if(j==0)
  var textnode=document.createTextNode(found["name"])
else
  var textnode=document.createTextNode(found["name"]+"->")

 document.getElementById("algotext").appendChild(textnode)
 })
 
}
//console.log(graph_1.topologicalSort())
  //g.printGraph()

}
}


