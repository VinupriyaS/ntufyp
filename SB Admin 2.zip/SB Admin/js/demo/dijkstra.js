d3.dijkstra = function () {
    var dijkstra = {}, nodes, edges, source, go,dispatch = d3.dispatch("start", "tick", "step", "end");
        var translate_speed = 5000;
    var color = d3.scale.linear().domain([0, 3, 10]).range(["green", "yellow", "red"]);

       var table,thead;


    dijkstra.run = function (src) {
       //alert ("HEEEYEYEL")
        
                clearInterval(go);
                resettable();
                 d3.selectAll(".node").style("fill","red")
                    d3.select('#node'+src.id).style('fill', '#fdb03f').style('stroke-width', '0');

       // console.log(d3.select(".nodes"))  //this only selects the g element --have to select the children of this g element

       table =  d3.select("#container")
    .append("foreignObject")
    .attr("id","tablecontainer")
    .attr("width", 500)
    .attr("height", 500)
    .append("xhtml:table")
     .attr("id","mytable");

  thead = table.append("thead"),
        tbody = table.append("tbody");
columns=["link","distance"]
  thead.append("tr")
        .selectAll("th")
        .data(columns)
        .enter()
        .append("th")
            .text(function(column) { return column; });
  
        source = src;
        //console.log(source);
        var unvisited = [];
        console.log(nodes)        
        nodes.forEach(function (d) {
          console.log(d)
            if (d != src) {
                d.distance = Infinity;
                unvisited.push(d);
                d.visited = false;
                d.path="";
            }
            console.log(unvisited)
        //console.log(src.name);
        
     
           //.log(linkededges)
        });

      
        var current = src;
           
                
        current.distance = 0;
        var linkededges=[]
       nodes.forEach(function(k){

            k.links= edges.filter(function(d){
               // console.log(d)
                //console.log(d.source.name)
               if(d.source.name===k.name  || d.target.name===k.name)
               { //console.log(k.name+"-"+d.target.name)
           return(d)

       }
            /*else if(d.target.name===k.name)
              { console.log(d.source.name+"-"+k.name)
          return(d)
      }*/
            })

        });
       console.log(nodes)
       console.log(unvisited)
        var distArray=[]
       
        unvisited.forEach(function(d){
           distArray.push({
                  "link":src.name+"-"+d.name,
                  "distance": "Infinity",
                  "path": "-"
                })
        })
        console.log(distArray)
        buildtable(distArray);
        var visited=[]
        function tick() {
          //alert("hehehe")
          console.log(current)
          visited.push(current)
            current.visited = true;
           // console.log(current.name);
            console.log(current.links)
            console.log(current.distance)
         // console.log(d3.select("#node"+current.id))
    $("#algotext").empty()
        var textnode=document.createTextNode("unvisited = [")
        document.getElementById("algotext").appendChild(textnode)

                 for(i=0;i<unvisited.length;i++){
          var textnode=document.createTextNode(unvisited[i].name+" ")

 document.getElementById("algotext").appendChild(textnode)
        }
          var textnode=document.createTextNode("]")
        document.getElementById("algotext").appendChild(textnode)
        document.getElementById("algotext").appendChild(document.createElement("br"))
        document.getElementById("algotext").appendChild(document.createTextNode("Visited = ["))
      for(i=0;i<visited.length;i++){
          var textnode=document.createTextNode(visited[i].name+" ")

 document.getElementById("algotext").appendChild(textnode)
        } var textnode=document.createTextNode("]")
        document.getElementById("algotext").appendChild(textnode)
          
          
            current.links.forEach(function(link) {
              console.log(link)
                if(document.getElementById("linktype").value==="undirected" && link.target==current){
                  var tar=link.source
                  var dist = current.distance + link.edgeweight;
                  console.log(dist)
                   if(dist<tar.distance)
                      tar.path=(current.path!=undefined?current.path:"")+current.name+tar.name

                    tar.distance = Math.min(dist, tar.distance);
                

                    d3.select('#node'+link.target.id).transition().delay(translate_speed/8).duration(7500).style("stroke","black").style("stroke-dasharray", ("10,3"))
                    console.log(current.name+"-"+tar.name)

                distArray.forEach(function(d){
                  if (d.link ==src.name+"-"+tar.name)
                   {
                    d.distance=tar.distance
                    d.path=tar.path
                    console.log(d)
                   }
                })
                  d3.select("#link"+current.name+tar.name).transition().delay(translate_speed/8).duration(7500).style("stroke","blue").style("stroke-width",3)

                }
               else{ var tar = link.target;
                console.log(tar);
                
                if (!tar.visited) {
                  //  console.log(current.distance);
                    //console.log(link.edgeweight);
                    //console.log(tar.id)
                    var dist = current.distance + link.edgeweight;
                     if(dist<tar.distance)
                      tar.path=(current.path!=undefined?current.path:"")+current.name+tar.name

                    tar.distance = Math.min(dist, tar.distance);
                  d3.select("#link"+current.name+tar.name).transition().delay(translate_speed/8).duration(7500).style("stroke","blue").style("stroke-width",3)

                    d3.select('#node'+link.target.id).transition().delay(translate_speed/8).duration(7500).style("stroke","black").style("stroke-dasharray", ("10,3"))
                    console.log(current.name+"-"+tar.name)

                distArray.forEach(function(d){
                  if (d.link ==src.name+"-"+tar.name)
                   {
                    d.distance=tar.distance
                    d.path=tar.path
                    console.log(d)
                   }
                })
                console.log(src.name+"-"+tar.name)
                //console.log(d3.select("#"+src.name+"-"+tar.name)[0])
                //transition().delay(translate_speed/8).duration(7500).style("fill","red")
                    

            /*    distArray.push({
                  "link":src.name+"-"+tar.name,
                  "distance": tar.distance,
                  "path": tar.path
                })*/
                console.log(distArray)

                }

            }
            });

            if (unvisited.length == 0 || current.distance == Infinity) {
                clearInterval(go);
                //dispatch.end()
                //return true;
            }
            unvisited.sort(function(a, b) {
                return b.distance - a.distance 
            });
          /*  unvisited.forEach(function(element){
               console.log(element)
           })*/
            
            current = unvisited.pop()
d3.select("#node"+current.id)
                .transition().delay(translate_speed*2/5).duration(translate_speed/5).attr('r', 6)
                .transition().duration(translate_speed/5).attr('r', 10)
                .style("fill", '#000080')
                .style('stroke-width', '0')
                .each("end", buildtable(distArray));


           

          
           
        }

         tick()
        go = setInterval(tick, translate_speed);
    };
    
   dijkstra.nodes = function (_) {
       // alert("NODES")
        //console.log(arguments)
        //console.log(arguments.length)
        if (!arguments.length)
            return nodes;
        else {
            nodes = _;
            return dijkstra;
        }
    };
   
   dijkstra.edges = function (_) {
    //console.log(arguments)
        if (!arguments.length)
            return edges;
        else {
            edges = _;
            return dijkstra;
        }
    };

   dijkstra.source = function(_) {
 //   console.log(arguments)
        if (!arguments.length)
            return source;
        else {
            source = _;
            return dijkstra;
        }
    };
function buildtable(data){
  console.log(data)
 

  
 // create a row for each object in the data
    var rows = tbody.selectAll("tr")
        .data(data)
        .attr("id",function(d){
          return d.link
        })

    console.log(rows)
        rows.enter()
        .append("tr")
        .on("click",function(d){
          //alert("HE");
          d3.selectAll("tr").style("background-color","")
          d3.select(this).style("background-color", "#fdb03f")
          console.log(d3.select(this).selectAll("td").text())
          var linkid=d3.select(this).selectAll("td").text()
          console.log(d.path)
          path=d.path
          pathids=path.match(new RegExp('.{1,' + 2 + '}', 'g'));
          console.log(pathids.length)
          for(i=0;i<pathids.length;i++){
            console.log(pathids[i])
            d3.selectAll(".link").style("stroke","black").style("stroke-dasharray",0)
            //console.log(document.getElementById("#link"+pathids[i]))
            if(document.getElementById("linktype").value==="undirected"){
              console.log(d3.select("#link"+pathids[i]))
              console.log(d3.select("#link"+pathids[i])[0]==null)
              if(d3.select("#link"+pathids[i][0])==null)
              {link_ids=pathids[i].split("").reverse().join("");
              console.log(link_ids)
              console.log( d3.select("#link"+link_ids))
               d3.select("#link"+link_ids).transition().delay(translate_speed/8).duration(7500).style("stroke-dasharray", ("3, 3"))
             }
               else
                d3.select("#link"+pathids[i]).transition().delay(translate_speed/8).duration(7500).style("stroke-dasharray", ("3, 3"))
            }
            else{
              d3.select("#link"+pathids[i]).transition().delay(translate_speed/8).duration(7500).style("stroke-dasharray", ("3, 3"))
            }
          }

          var parent=d3.select(this)
     children= parent
    //Convert selection to selection representing the children
    .selectAll(function() { return this.childNodes; })
    //Apply filter to children
    .filter('td')
    console.log(children[0][0])

        })

    // create a cell in each row for each column
    var cells = rows.selectAll("td")
        .data(function(row) {
            return columns.map(function(column) {
              console.log(column)
              console.log(row)
              console.log(row[column])
                return {column: column, value: row[column]};
            });
        })

    cells.html(function(d) { return d.value; });

        cells.enter()
        .append("td")
        .attr("style", "font-family: Courier")
            .html(function(d) { return d.value; });
}


function resettable(){
   d3.select("#mytable").remove();
            d3.select("#tablecontainer").remove();
}
    
   dispatch.on("start.code", dijkstra.run);
   
   return d3.rebind(dijkstra, dispatch, "on", "end", "start", "tick");
};


