class Graph {
   constructor() {
      this.edges = {};
      this.nodes = [];
   }
   addNode(node) {
      this.nodes.push(node);
      this.edges[node] = [];
   }
   addEdge(node1, node2) {
      this.edges[node1].push(node2);
      this.edges[node2].push(node1);
   }
   addDirectedEdge(node1, node2) {
      this.edges[node1].push(node2);
   }
   display() {
      let graph = ""; this.nodes.forEach(node => {
         graph += node + "->" + this.edges[node].join(", ") + "\n";
      });
      console.log(graph);
   }
topologicalSortHelper(node, explored, s) {
   console.log(node)
   explored.add(node);
   // Marks this node as visited and goes on to the nodes
   // that are dependent on this node, the edge is node ----> n
   this.edges[node].forEach(n => {
      if (!explored.has(n)) {
         this.topologicalSortHelper(n, explored, s);
      }
   });
   // All dependencies are resolved for this node, we can now add
   // This to the stack.
   s.push(node);
}

topologicalSort() {
   // Create a Stack to keep track of all elements in sorted order
   //let s = new Stack(this.nodes.length);
   let s=[]
   let explored = new Set();
   console.log(this.nodes)
   // For every unvisited node in our graph, call the helper.
   this.nodes.forEach(node => {
      if (!explored.has(node)) {
         console.log(node)
         this.topologicalSortHelper(node, explored, s);
         console.log(s)
      }
   });
  // console.log(s)
   console.log(s.length)
  for(var j=s.length-1;j>=0;j--)
   console.log(s[j])
return s
}

}